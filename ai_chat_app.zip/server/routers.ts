import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { createChatSession, getChatSessions, getChatSession, updateChatSessionTitle, deleteChatSession, addChatMessage, getChatMessages, createLearningItem, getLearningItems, getRecentConversationContext, extractConversationTopics, getStripeProducts, getStripePrices, getUserSubscription, recordPayment } from "./db";
import { invokeLLM } from "./_core/llm";
import { generateImage } from "./_core/imageGeneration";
import { processUserMessage } from "./_core/unifiedAI";
import { generateWebApp, generateGame, generatePDF, generateCSV, generatePowerPoint } from "./_core/generationEngine";
import { createCheckoutSession } from "./_core/stripe";
import { executePythonCode, isSafeCode } from "./pythonExecutor";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Chat routers
  chat: router({
    createSession: protectedProcedure
      .input(z.object({ title: z.string().optional(), mode: z.enum(['chat', 'learning']).default('chat') }))
      .mutation(async ({ ctx, input }) => {
        const sessionId = await createChatSession(ctx.user.id, input.title || 'New Chat', input.mode);
        return { sessionId };
      }),
    
    getSessions: protectedProcedure
      .query(async ({ ctx }) => {
        return getChatSessions(ctx.user.id);
      }),
    
    getMessages: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ ctx, input }) => {
        const session = await getChatSession(input.sessionId, ctx.user.id);
        if (!session) throw new Error('Session not found');
        return getChatMessages(input.sessionId);
      }),
    
    sendMessage: protectedProcedure
      .input(z.object({ sessionId: z.number(), content: z.string(), fileData: z.array(z.object({ name: z.string(), size: z.number(), type: z.string() })).optional() }))
      .mutation(async ({ ctx, input }) => {
        const session = await getChatSession(input.sessionId, ctx.user.id);
        if (!session) throw new Error('Session not found');
        
        // Save user message
        await addChatMessage(input.sessionId, 'user', input.content);
        
        // Get recent conversation context for better understanding
        const recentMessages = await getRecentConversationContext(input.sessionId, 10);
        const conversationHistory = recentMessages.map(m => ({
          role: m.role as 'user' | 'assistant',
          content: m.content,
        }));
        
        // Extract conversation topics for context awareness
        const topics = extractConversationTopics(conversationHistory);
        const contextAwareness = topics.length > 0 ? `\n\n[会話のコンテキスト: ${topics.join(', ')}]` : '';
        
        // Use unified AI service with context awareness
        const userMessageWithContext = input.content + contextAwareness;
        const aiResponse = await processUserMessage(userMessageWithContext, conversationHistory);
        
        // Save assistant message with optional image
        await addChatMessage(input.sessionId, 'assistant', aiResponse.text, aiResponse.imageUrl);
        
        // Check if slide creation is needed
        let slideData: any = undefined;
        if (aiResponse.shouldCreateSlides && aiResponse.slideTopic) {
          try {
            const slideResponse = await appRouter.createCaller(ctx).content.createSlides({
              sessionId: input.sessionId,
              topic: aiResponse.slideTopic,
              slideCount: 5
            });
            slideData = slideResponse.slideData;
          } catch (error) {
            console.error('Slide creation failed:', error);
          }
        }
        
        // Check if app creation is needed
        let appData: any = undefined;
        if (aiResponse.shouldCreateApp && aiResponse.appDescription) {
          try {
            const appResponse = await appRouter.createCaller(ctx).content.createApp({
              sessionId: input.sessionId,
              appDescription: aiResponse.appDescription,
              appType: 'website'
            });
            appData = appResponse.appData;
          } catch (error) {
            console.error('App creation failed:', error);
          }
        }
        
        // Check if audio generation is needed
        let audioData: any = undefined;
        if (aiResponse.shouldGenerateAudio && aiResponse.audioText) {
          audioData = { type: 'audio', description: aiResponse.audioText, status: 'pending' };
        }
        
        // Check if video generation is needed
        let videoData: any = undefined;
        if (aiResponse.shouldGenerateVideo && aiResponse.videoDescription) {
          videoData = { type: 'video', description: aiResponse.videoDescription, status: 'pending' };
        }
        
        // Check if PDF generation is needed
        let pdfData: any = undefined;
        if (aiResponse.shouldGeneratePDF && aiResponse.pdfContent) {
          pdfData = { type: 'pdf', content: aiResponse.pdfContent, status: 'pending' };
        }
        
        // Check if game creation is needed
        let gameData: any = undefined;
        if (aiResponse.shouldCreateGame && aiResponse.gameDescription) {
          gameData = { type: 'game', description: aiResponse.gameDescription, status: 'pending' };
        }
        
        // Check if website creation is needed
        let websiteData: any = undefined;
        if (aiResponse.shouldCreateWebsite && aiResponse.websiteDescription) {
          websiteData = { type: 'website', description: aiResponse.websiteDescription, status: 'pending' };
        }
        
        return { 
          message: aiResponse.text, 
          imageUrl: aiResponse.imageUrl, 
          slideData, 
          appData,
          audioData,
          videoData,
          pdfData,
          gameData,
          websiteData
        };
      }),
    
    renameSession: protectedProcedure
      .input(z.object({ sessionId: z.number(), title: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const success = await updateChatSessionTitle(input.sessionId, ctx.user.id, input.title);
        if (!success) throw new Error('Session not found');
        return { success: true };
      }),
    
    // Generation endpoints
    generateWebApp: protectedProcedure
      .input(z.object({ prompt: z.string() }))
      .mutation(async ({ input }) => {
        return generateWebApp(input.prompt);
      }),
    
    generateGame: protectedProcedure
      .input(z.object({ prompt: z.string() }))
      .mutation(async ({ input }) => {
        return generateGame(input.prompt);
      }),
    
    generatePDF: protectedProcedure
      .input(z.object({ title: z.string(), content: z.string() }))
      .mutation(async ({ input }) => {
        return generatePDF(input.title, input.content);
      }),
    
    generateCSV: protectedProcedure
      .input(z.object({ title: z.string(), data: z.string() }))
      .mutation(async ({ input }) => {
        return generateCSV(input.title, input.data);
      }),
    
    generatePowerPoint: protectedProcedure
      .input(z.object({ title: z.string(), slides: z.array(z.string()) }))
      .mutation(async ({ input }) => {
        return generatePowerPoint(input.title, input.slides);
      }),
    
    deleteSession: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const success = await deleteChatSession(input.sessionId, ctx.user.id);
        if (!success) throw new Error('Session not found');
        return { success: true };
      }),
  }),
  
  // Image generation router
  image: router({
    generate: protectedProcedure
      .input(z.object({ sessionId: z.number(), prompt: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const session = await getChatSession(input.sessionId, ctx.user.id);
        if (!session) throw new Error('Session not found');
        
        // Generate image
        const { url } = await generateImage({ prompt: input.prompt });
        
        // Save image message
        await addChatMessage(input.sessionId, 'assistant', `Generated image for: ${input.prompt}`, url);
        
        return { imageUrl: url };
      }),
  }),
  
  // Learning support router
  learning: router({
    getQuestion: protectedProcedure
      .input(z.object({ sessionId: z.number(), topic: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const session = await getChatSession(input.sessionId, ctx.user.id);
        if (!session) throw new Error('Session not found');
        
        // Generate learning question
        const response = await invokeLLM({
          messages: [
            { role: 'system', content: 'You are an educational tutor. Generate a clear, engaging learning question. Respond in JSON format: {"question": "...", "difficulty": "easy|medium|hard"}' },
            { role: 'user', content: input.topic ? `Generate a ${input.topic} question` : 'Generate a general learning question' },
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'learning_question',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  question: { type: 'string' },
                  difficulty: { type: 'string', enum: ['easy', 'medium', 'hard'] },
                },
                required: ['question', 'difficulty'],
                additionalProperties: false,
              },
            },
          },
        });
        
        const content = typeof response.choices[0].message.content === 'string' ? response.choices[0].message.content : '';
        const data = JSON.parse(content);
        const itemId = await createLearningItem(input.sessionId, 'problem', data.question, undefined, undefined, data.difficulty);
        
        return { itemId, question: data.question, difficulty: data.difficulty };
      }),
    
    getExplanation: protectedProcedure
      .input(z.object({ sessionId: z.number(), itemId: z.number(), userAnswer: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const session = await getChatSession(input.sessionId, ctx.user.id);
        if (!session) throw new Error('Session not found');
        
        const learningItems = await getLearningItems(input.sessionId);
        const item = learningItems.find(i => i.id === input.itemId);
        if (!item) throw new Error('Learning item not found');
        
        // Generate explanation
        const response = await invokeLLM({
          messages: [
            { role: 'system', content: 'You are an educational tutor. Provide a detailed, encouraging explanation for the learning question and user answer.' },
            { role: 'user', content: `Question: ${item.question}\n\nUser Answer: ${input.userAnswer}\n\nProvide feedback and explanation.` },
          ],
        });
        
        const explanation = typeof response.choices[0].message.content === 'string' ? response.choices[0].message.content : '';
        
        return { explanation };
      }),
  }),

  // Content creation routers
  content: router({
    createSlides: protectedProcedure
      .input(z.object({ sessionId: z.number(), topic: z.string(), slideCount: z.number().default(5) }))
      .mutation(async ({ ctx, input }) => {
        const session = await getChatSession(input.sessionId, ctx.user.id);
        if (!session) throw new Error('Session not found');
        
        // Generate slide content using LLM
        const response = await invokeLLM({
          messages: [
            { role: 'system', content: 'You are a presentation expert. Generate slide content in JSON format with title, slides array containing title and content for each slide.' },
            { role: 'user', content: `Create ${input.slideCount} slides about: ${input.topic}. Return JSON format: {"title": "...", "slides": [{"title": "...", "content": "..."}]}` },
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'slide_content',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  slides: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        title: { type: 'string' },
                        content: { type: 'string' },
                      },
                      required: ['title', 'content'],
                      additionalProperties: false,
                    },
                  },
                },
                required: ['title', 'slides'],
                additionalProperties: false,
              },
            },
          },
        });
        
        const content = typeof response.choices[0].message.content === 'string' ? response.choices[0].message.content : '';
        const slideData = JSON.parse(content);
        
        // Save to chat message
        await addChatMessage(input.sessionId, 'assistant', `Created presentation: ${slideData.title}\n\n${JSON.stringify(slideData)}`);
        
        return { slideData, message: `Presentation "${slideData.title}" created successfully!` };
      }),
    
    createApp: protectedProcedure
      .input(z.object({ sessionId: z.number(), appDescription: z.string(), appType: z.enum(['website', 'dashboard', 'tool']).default('website') }))
      .mutation(async ({ ctx, input }) => {
        const session = await getChatSession(input.sessionId, ctx.user.id);
        if (!session) throw new Error('Session not found');
        
        // Generate app structure using LLM
        const response = await invokeLLM({
          messages: [
            { role: 'system', content: 'You are a web developer. Generate app structure in JSON format with name, description, features array, and technology stack.' },
            { role: 'user', content: `Create a ${input.appType} app with: ${input.appDescription}. Return JSON format: {"name": "...", "description": "...", "features": [...], "tech_stack": [...]}` },
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'app_structure',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  description: { type: 'string' },
                  features: {
                    type: 'array',
                    items: { type: 'string' },
                  },
                  tech_stack: {
                    type: 'array',
                    items: { type: 'string' },
                  },
                },
                required: ['name', 'description', 'features', 'tech_stack'],
                additionalProperties: false,
              },
            },
          },
        });
        
        const content = typeof response.choices[0].message.content === 'string' ? response.choices[0].message.content : '';
        const appData = JSON.parse(content);
        
        // Save to chat message
        await addChatMessage(input.sessionId, 'assistant', `App plan created: ${appData.name}\n\n${JSON.stringify(appData)}`);
        
        return { appData, message: `App "${appData.name}" plan created successfully!` };
            }),
  }),

  // Stripe payment routers
  payment: router({
    getProducts: publicProcedure
      .query(async () => {
        return getStripeProducts();
      }),
    
    getPrices: publicProcedure
      .input(z.object({ productId: z.string() }))
      .query(async ({ input }) => {
        return getStripePrices(input.productId);
      }),
    
    getUserSubscription: protectedProcedure
      .query(async ({ ctx }) => {
        return getUserSubscription(ctx.user.id);
      }),
    
    createCheckoutSession: protectedProcedure
      .input(z.object({ priceId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        try {
          const session = await createCheckoutSession({
            priceId: input.priceId,
            customerEmail: ctx.user.email || undefined,
            successUrl: `${process.env.VITE_FRONTEND_URL || 'http://localhost:5173'}/payment/success`,
            cancelUrl: `${process.env.VITE_FRONTEND_URL || 'http://localhost:5173'}/payment/cancel`,
            metadata: {
              userId: ctx.user.id.toString(),
              userEmail: ctx.user.email || '',
            },
          });
          return {
            sessionId: session.id,
            url: session.url || '',
          };
        } catch (error) {
          console.error('Checkout session creation failed:', error);
          throw new Error('Failed to create checkout session');
        }
      }),
  }),

  // Python execution router
  python: router({
    execute: protectedProcedure
      .input(z.object({ code: z.string() }))
      .mutation(async ({ ctx, input }) => {
        // セキュリティチェック
        const safetyCheck = isSafeCode(input.code);
        if (!safetyCheck.safe) {
          return {
            success: false,
            error: safetyCheck.reason || '安全でないコードです',
          };
        }

        // Pythonコードを実行
        const result = await executePythonCode(input.code);
        return result;
      }),
  }),
});
export type AppRouter = typeof appRouter;
