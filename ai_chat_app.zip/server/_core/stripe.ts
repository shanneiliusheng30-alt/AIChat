import { ENV } from "./env";

/**
 * Initialize Stripe SDK
 * Returns null if Stripe is not configured
 */
export function getStripeClient() {
  if (!ENV.stripeSecretKey) {
    console.warn("[Stripe] Secret key not configured");
    return null;
  }

  try {
    // Dynamic import to avoid hard dependency on stripe package
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Stripe = require("stripe");
    return new Stripe(ENV.stripeSecretKey, {
      apiVersion: "2024-04-10",
    });
  } catch (error) {
    console.error("[Stripe] Failed to initialize Stripe client:", error);
    return null;
  }
}

/**
 * Create a checkout session for a customer
 */
export async function createCheckoutSession(options: {
  priceId: string;
  customerId?: string;
  customerEmail?: string;
  successUrl: string;
  cancelUrl: string;
  metadata?: Record<string, string>;
}) {
  const stripe = getStripeClient();
  if (!stripe) {
    throw new Error("Stripe is not configured");
  }

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price: options.priceId,
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: options.successUrl,
      cancel_url: options.cancelUrl,
      customer_email: options.customerEmail,
      customer: options.customerId,
      metadata: options.metadata,
      allow_promotion_codes: true,
    });

    return session;
  } catch (error) {
    console.error("[Stripe] Failed to create checkout session:", error);
    throw error;
  }
}

/**
 * Verify webhook signature
 */
export function verifyWebhookSignature(
  body: string | Buffer,
  signature: string
): Record<string, unknown> | null {
  if (!ENV.stripeWebhookSecret) {
    console.warn("[Stripe] Webhook secret not configured");
    return null;
  }

  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Stripe = require("stripe");
    const stripe = new Stripe(ENV.stripeSecretKey);
    const event = stripe.webhooks.constructEvent(
      body,
      signature,
      ENV.stripeWebhookSecret
    );
    return event;
  } catch (error) {
    console.error("[Stripe] Webhook signature verification failed:", error);
    return null;
  }
}

/**
 * Get a payment intent by ID
 */
export async function getPaymentIntent(paymentIntentId: string) {
  const stripe = getStripeClient();
  if (!stripe) {
    throw new Error("Stripe is not configured");
  }

  try {
    return await stripe.paymentIntents.retrieve(paymentIntentId);
  } catch (error) {
    console.error("[Stripe] Failed to retrieve payment intent:", error);
    throw error;
  }
}

/**
 * Get a subscription by ID
 */
export async function getSubscription(subscriptionId: string) {
  const stripe = getStripeClient();
  if (!stripe) {
    throw new Error("Stripe is not configured");
  }

  try {
    return await stripe.subscriptions.retrieve(subscriptionId);
  } catch (error) {
    console.error("[Stripe] Failed to retrieve subscription:", error);
    throw error;
  }
}
