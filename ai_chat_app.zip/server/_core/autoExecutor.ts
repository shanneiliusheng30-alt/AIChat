/**
 * Auto Executor Engine
 * Automatically executes tasks based on user instructions
 */

import { invokeLLM } from "./llm";

export interface AutoTask {
  type: "search" | "generate" | "analyze" | "summarize" | "translate" | "code" | "image" | "audio";
  description: string;
  parameters?: Record<string, any>;
  priority?: number;
}

export interface ExecutionResult {
  taskType: string;
  status: "success" | "failed" | "pending";
  result?: any;
  error?: string;
  executedAt: number;
}

/**
 * Parse user instruction and extract tasks
 */
export async function parseInstructions(userInput: string): Promise<AutoTask[]> {
  const systemPrompt = `You are a task parser. Analyze the user's instruction and extract specific tasks to execute.
Return a JSON array of tasks with the following structure:
[
  {
    "type": "search|generate|analyze|summarize|translate|code|image|audio",
    "description": "detailed task description",
    "parameters": { "key": "value" },
    "priority": 1-10
  }
]

Task types:
- search: Search for information
- generate: Generate content (text, code, etc.)
- analyze: Analyze provided content
- summarize: Summarize content
- translate: Translate text
- code: Generate or fix code
- image: Generate images
- audio: Generate audio

Return ONLY valid JSON, no other text.`;

  try {
    const response = await invokeLLM({
      model: "claude-3-5-sonnet-20241022",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userInput },
      ],
    });

    const content = response.choices[0]?.message?.content || "[]";
    const contentStr = typeof content === "string" ? content : "[]";
    const tasks = JSON.parse(contentStr);
    return Array.isArray(tasks) ? tasks : [];
  } catch (error) {
    console.error("Task parsing error:", error);
    return [];
  }
}

/**
 * Execute a single task
 */
export async function executeTask(task: AutoTask): Promise<ExecutionResult> {
  const startTime = Date.now();

  try {
    switch (task.type) {
      case "search":
        return await executeSearch(task);
      case "generate":
        return await executeGenerate(task);
      case "analyze":
        return await executeAnalyze(task);
      case "summarize":
        return await executeSummarize(task);
      case "translate":
        return await executeTranslate(task);
      case "code":
        return await executeCode(task);
      case "image":
        return await executeImage(task);
      case "audio":
        return await executeAudio(task);
      default:
        return {
          taskType: task.type,
          status: "failed",
          error: `Unknown task type: ${task.type}`,
          executedAt: Date.now(),
        };
    }
  } catch (error) {
    return {
      taskType: task.type,
      status: "failed",
      error: error instanceof Error ? error.message : "Unknown error",
      executedAt: Date.now(),
    };
  }
}

async function executeSearch(task: AutoTask): Promise<ExecutionResult> {
  const query = task.parameters?.query || task.description;
  
  // Use Manus Data API for search
  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      {
        role: "user",
        content: `Search for information about: ${query}. Provide a comprehensive answer.`,
      },
    ],
  });

  return {
    taskType: "search",
    status: "success",
    result: response.choices[0]?.message?.content,
    executedAt: Date.now(),
  };
}

async function executeGenerate(task: AutoTask): Promise<ExecutionResult> {
  const prompt = task.parameters?.prompt || task.description;
  
  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      {
        role: "user",
        content: prompt,
      },
    ],
  });

  return {
    taskType: "generate",
    status: "success",
    result: response.choices[0]?.message?.content,
    executedAt: Date.now(),
  };
}

async function executeAnalyze(task: AutoTask): Promise<ExecutionResult> {
  const content = task.parameters?.content || task.description;
  
  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      {
        role: "user",
        content: `Analyze the following content and provide insights:\n\n${content}`,
      },
    ],
  });

  return {
    taskType: "analyze",
    status: "success",
    result: response.choices[0]?.message?.content,
    executedAt: Date.now(),
  };
}

async function executeSummarize(task: AutoTask): Promise<ExecutionResult> {
  const content = task.parameters?.content || task.description;
  
  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      {
        role: "user",
        content: `Summarize the following content concisely:\n\n${content}`,
      },
    ],
  });

  return {
    taskType: "summarize",
    status: "success",
    result: response.choices[0]?.message?.content,
    executedAt: Date.now(),
  };
}

async function executeTranslate(task: AutoTask): Promise<ExecutionResult> {
  const content = task.parameters?.content || task.description;
  const targetLanguage = task.parameters?.targetLanguage || "English";
  
  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      {
        role: "user",
        content: `Translate the following text to ${targetLanguage}:\n\n${content}`,
      },
    ],
  });

  return {
    taskType: "translate",
    status: "success",
    result: response.choices[0]?.message?.content,
    executedAt: Date.now(),
  };
}

async function executeCode(task: AutoTask): Promise<ExecutionResult> {
  const requirement = task.parameters?.requirement || task.description;
  
  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      {
        role: "user",
        content: `Generate code for the following requirement:\n\n${requirement}`,
      },
    ],
  });

  return {
    taskType: "code",
    status: "success",
    result: response.choices[0]?.message?.content,
    executedAt: Date.now(),
  };
}

async function executeImage(task: AutoTask): Promise<ExecutionResult> {
  // Image generation would require additional API integration
  return {
    taskType: "image",
    status: "pending",
    result: "Image generation requires additional setup",
    executedAt: Date.now(),
  };
}

async function executeAudio(task: AutoTask): Promise<ExecutionResult> {
  // Audio generation would require additional API integration
  return {
    taskType: "audio",
    status: "pending",
    result: "Audio generation requires additional setup",
    executedAt: Date.now(),
  };
}

/**
 * Execute multiple tasks in sequence
 */
export async function executeTasks(tasks: AutoTask[]): Promise<ExecutionResult[]> {
  const results: ExecutionResult[] = [];
  
  // Sort by priority (higher priority first)
  const sortedTasks = tasks.sort((a, b) => (b.priority || 5) - (a.priority || 5));
  
  for (const task of sortedTasks) {
    const result = await executeTask(task);
    results.push(result);
  }
  
  return results;
}
