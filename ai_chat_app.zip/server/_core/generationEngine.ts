import { invokeLLM } from "./llm";
import { generateImage } from "./imageGeneration";
import { storagePut } from "../storage";
import { PDFDocument, rgb } from "pdf-lib";
import * as XLSX from "xlsx";
import PptxGenJS from "pptxgenjs";

/**
 * Generate Webアプリ（HTML/CSS/JavaScript）
 */
export async function generateWebApp(prompt: string): Promise<{ code: string; url: string }> {
  const systemPrompt = `You are an expert web developer. Generate a complete, self-contained HTML5 web application based on the user's request. 
Include HTML, CSS, and JavaScript all in a single file. Make it interactive and visually appealing.
Return ONLY the HTML code, starting with <!DOCTYPE html>.`;

  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: prompt },
    ],
  });

  const code = typeof response.choices[0]?.message?.content === "string" 
    ? response.choices[0].message.content 
    : "";

  // Upload to storage
  const { url } = await storagePut(
    `webapps/${Date.now()}.html`,
    code,
    "text/html"
  );

  return { code, url };
}

/**
 * Generate ゲーム（HTML5 Canvas-based）
 */
export async function generateGame(prompt: string): Promise<{ code: string; url: string }> {
  const systemPrompt = `You are an expert game developer. Generate a complete, playable HTML5 game using Canvas API based on the user's request.
Include HTML, CSS, and JavaScript all in a single file. Make it fun and interactive with proper game mechanics.
Return ONLY the HTML code, starting with <!DOCTYPE html>.`;

  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: prompt },
    ],
  });

  const code = typeof response.choices[0]?.message?.content === "string" 
    ? response.choices[0].message.content 
    : "";

  // Upload to storage
  const { url } = await storagePut(
    `games/${Date.now()}.html`,
    code,
    "text/html"
  );

  return { code, url };
}

/**
 * Generate PDF
 */
export async function generatePDF(title: string, content: string): Promise<{ url: string }> {
  const pdfDoc = await PDFDocument.create();
  let page = pdfDoc.addPage([600, 800]);
  const { height } = page.getSize();

  // Add title
  page.drawText(title, {
    x: 50,
    y: height - 50,
    size: 24,
    color: rgb(0, 0, 0),
  });

  // Add content (simple text wrapping)
  const lines = content.split("\n");
  let yPosition = height - 100;
  const lineHeight = 20;

  for (const line of lines) {
    if (yPosition < 50) {
      page = pdfDoc.addPage([600, 800]);
      yPosition = height - 50;
    }
    page.drawText(line, {
      x: 50,
      y: yPosition,
      size: 12,
      color: rgb(0, 0, 0),
    });
    yPosition -= lineHeight;
  }

  const pdfBytes = await pdfDoc.save();
  const { url } = await storagePut(
    `pdfs/${Date.now()}.pdf`,
    pdfBytes,
    "application/pdf"
  );

  return { url };
}

/**
 * Generate CSV
 */
export async function generateCSV(title: string, data: string): Promise<{ url: string }> {
  // Parse data into CSV format
  const lines = data.split("\n").filter(line => line.trim());
  const csv = lines.join("\n");

  // Add UTF-8 BOM to ensure proper encoding in Excel
  const bom = Buffer.from([0xEF, 0xBB, 0xBF]);
  const csvBuffer = Buffer.concat([bom, Buffer.from(csv, "utf-8")]);

  const { url } = await storagePut(
    `csvs/${Date.now()}.csv`,
    csvBuffer,
    "text/csv; charset=utf-8"
  );

  return { url };
}

/**
 * Generate PowerPoint
 */
export async function generatePowerPoint(title: string, slides: string[]): Promise<{ url: string }> {
  const prs = new (PptxGenJS as any)();

  // Add title slide
  const slide = prs.addSlide();
  slide.background = { color: "0066CC" };
  slide.addText(title, {
    x: 0.5,
    y: 2,
    w: 9,
    h: 1,
    fontSize: 44,
    bold: true,
    color: "FFFFFF",
    align: "center",
  });

  // Add content slides
  for (const content of slides) {
    const contentSlide = prs.addSlide();
    contentSlide.background = { color: "FFFFFF" };
    contentSlide.addText(content, {
      x: 0.5,
      y: 0.5,
      w: 9,
      h: 6.5,
      fontSize: 18,
      color: "000000",
      align: "left",
    });
  }

  // Save to buffer
  const pptxBuffer = await prs.write({ outputType: "arraybuffer" });
  
  const { url } = await storagePut(
    `pptx/${Date.now()}.pptx`,
    Buffer.from(pptxBuffer as unknown as ArrayBuffer),
    "application/vnd.openxmlformats-officedocument.presentationml.presentation"
  );

  return { url };
}

/**
 * Generate Webサイト（HTML/CSS/JavaScript）
 */
export async function generateWebsite(prompt: string): Promise<{ code: string; url: string }> {
  const systemPrompt = `You are an expert web designer and developer. Generate a complete, professional, and visually appealing website based on the user's request.
Include HTML, CSS, and JavaScript all in a single file. Create a modern, responsive design with proper styling and interactivity.
The website should include multiple sections, navigation, and professional styling.
Return ONLY the HTML code, starting with <!DOCTYPE html>.`;

  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: prompt },
    ],
  });

  const code = typeof response.choices[0]?.message?.content === "string" 
    ? response.choices[0].message.content 
    : "";

  // Upload to storage
  const { url } = await storagePut(
    `websites/${Date.now()}.html`,
    code,
    "text/html"
  );

  return { code, url };
}

/**
 * Generate 動画（MP4形式）
 * Note: 実際の動画生成はManus APIを通じて実行されます
 */
export async function generateVideo(prompt: string): Promise<{ url: string }> {
  // 動画生成はManus APIの動画生成サービスを使用します
  // ここではプレースホルダーとして実装
  try {
    // 実際の実装では、Manus APIの動画生成エンドポイントを呼び出します
    // const response = await fetch(`${BUILT_IN_FORGE_API_URL}/v1/video/generate`, {
    //   method: 'POST',
    //   headers: {
    //     'Authorization': `Bearer ${BUILT_IN_FORGE_API_KEY}`,
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({ prompt }),
    // });
    // const data = await response.json();
    // return { url: data.videoUrl };
    
    // プレースホルダー: 動画生成は現在利用不可
    throw new Error("動画生成機能は現在開発中です");
  } catch (error) {
    console.error("Video generation error:", error);
    throw error;
  }
}
