import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { streamLLM } from "./llm";
import { sdk } from "./sdk";
import { getChatSession, addChatMessage, getChatMessages } from "../db";
import { generateImage } from "./imageGeneration";
import { generateAudio } from "./audioGeneration";
import { detectTasks } from "./unifiedAI";
import { verifyWebhookSignature } from "./stripe";
import { recordPayment, updateUserSubscription } from "../db";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Stripe Webhook endpoint - must be registered BEFORE express.json()
  app.post(
    "/api/stripe/webhook",
    express.raw({ type: "application/json" }),
    async (req, res) => {
      const signature = req.headers["stripe-signature"] as string;
      if (!signature) {
        return res.status(400).json({ error: "Missing signature" });
      }

      try {
        const event = verifyWebhookSignature(req.body, signature);
        if (!event) {
          return res.status(400).json({ error: "Invalid signature" });
        }

        // Handle test events
        if ((event.id as string).startsWith("evt_test_")) {
          console.log("[Webhook] Test event detected, returning verification response");
          return res.json({ verified: true });
        }

        // Handle checkout.session.completed
        if (event.type === "checkout.session.completed") {
          const session = (event.data as any).object as any;
          const userId = parseInt(session.metadata?.userId || "0");
          const priceId = session.line_items?.[0]?.price?.id || "";

          if (userId && priceId) {
            // Record payment
            await recordPayment({
              userId,
              stripePaymentIntentId: session.payment_intent || "",
              stripePriceId: priceId,
              amount: session.amount_total || 0,
              currency: session.currency || "usd",
              status: "succeeded",
            });
            
            // Update user subscription
            await updateUserSubscription(
              userId,
              priceId,
              session.subscription || ""
            );
            
            console.log(`[Webhook] Payment recorded and subscription updated for user ${userId}`);
          }
        }

        // Handle payment_intent.succeeded
        if (event.type === "payment_intent.succeeded") {
          const paymentIntent = (event.data as any).object as any;
          console.log(`[Webhook] Payment intent succeeded: ${paymentIntent.id}`);
        }

        res.json({ received: true });
      } catch (error) {
        console.error("[Webhook] Error processing webhook:", error);
        res.status(400).json({ error: "Webhook processing failed" });
      }
    }
  );

  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  
  // Streaming chat endpoint
  app.post("/api/chat/stream", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }

      const { sessionId, message } = req.body as { sessionId: number; message: string };
      if (!sessionId || !message) {
        res.status(400).json({ error: "Missing sessionId or message" });
        return;
      }

      // Verify session ownership
      const session = await getChatSession(sessionId, user.id);
      if (!session) {
        res.status(404).json({ error: "Session not found" });
        return;
      }

      // Save user message
      await addChatMessage(sessionId, "user", message);

      // Get conversation history
      const messages = await getChatMessages(sessionId);
      const conversationHistory = messages.map(m => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      }));

      // Set up SSE headers
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.setHeader("Access-Control-Allow-Origin", "*");

      let fullResponse = "";
      let imageUrl: string | undefined;
      let audioUrl: string | undefined;
      let webAppUrl: string | undefined;
      let gameUrl: string | undefined;
      let pdfUrl: string | undefined;
      let csvUrl: string | undefined;
      let pptUrl: string | undefined;
      let websiteUrl: string | undefined;
      let pythonCode: string | undefined;

      // Detect tasks to be executed
      const detectedTasks = detectTasks(message);
      res.write(`data: ${JSON.stringify({ type: "tasks", tasks: detectedTasks })}\n\n`);

      // Stream the response
      try {
        // Check if we need to generate various message types
        const imageKeywords = /(画像|描画|絵|画を描画|image|draw|create|generate|picture|photo|illustration|design)/i;
        const audioKeywords = /(音声|音|音声を生成|音声作成|speak|voice|audio|read|narrate|speech)/i;
        const videoKeywords = /(動画|動画を作成|動画を生成|video|movie|film|generate video|create video)/i;
        const webAppKeywords = /(Webアプリ|ウェブアプリ|web app|application|tool|dashboard)/i;
        const websiteKeywords = /(Webサイト|ウェブサイト|website|web site|homepage|landing page)/i;
        const gameKeywords = /(ゲーム|game|gaming|interactive game|create game)/i;
        const pdfKeywords = /(PDF|pdf|document|report|generate pdf)/i;
        const csvKeywords = /(CSV|csv|data|spreadsheet|table)/i;
        const pptKeywords = /(パワーポイント|PowerPoint|プレゼンテーション|presentation|slides?)/i;
        const pythonKeywords = /(Python|python|コードを書いて|コードを生成|データ分析|グラフ|計算|code|script|script to)/i;
        
        const shouldGenerateImage = imageKeywords.test(message);
        const shouldGenerateAudio = audioKeywords.test(message);
        const shouldGenerateVideo = videoKeywords.test(message);
        const shouldGenerateWebApp = webAppKeywords.test(message) && !websiteKeywords.test(message);
        const shouldGenerateWebsite = websiteKeywords.test(message);
        const shouldGenerateGame = gameKeywords.test(message);
        const shouldGeneratePDF = pdfKeywords.test(message);
        const shouldGenerateCSV = csvKeywords.test(message);
        const shouldGeneratePPT = pptKeywords.test(message);
        const shouldGeneratePython = pythonKeywords.test(message);
        
        // Update text generation task status to running
        res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "text", status: "running" })}\n\n`);

        // Stream LLM response
        await streamLLM(
          {
            messages: [
              { role: "system", content: "You are a helpful AI assistant with image generation capabilities. You can generate images when users ask for them. Always provide clear, concise, and educational responses. When users ask you to create, draw, generate, or describe an image, you will automatically generate an image for them." },
              ...conversationHistory,
              { role: "user", content: message },
            ],
          },
          (chunk) => {
            fullResponse += chunk;
            res.write(`data: ${JSON.stringify({ type: "text", content: chunk })}\n\n`);
          }
        );
        
        // Update text generation task status to completed
        res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "text", status: "completed" })}\n\n`);

        // Generate image if needed
        if (shouldGenerateImage) {
          try {
            // Update image generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "image", status: "running" })}\n\n`);
            
            const imageResponse = await generateImage({ prompt: message });
            imageUrl = imageResponse.url;
            res.write(`data: ${JSON.stringify({ type: "image", url: imageUrl })}\n\n`);
            
            // Update image generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "image", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("Image generation failed:", error);
            // Update image generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "image", status: "error" })}\n\n`);
          }
        }

        // Generate audio if needed
        if (shouldGenerateAudio) {
          try {
            // Update audio generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "audio", status: "running" })}\n\n`);
            
            const audioResponse = await generateAudio({ text: fullResponse, language: "ja" });
            audioUrl = audioResponse.url;
            res.write(`data: ${JSON.stringify({ type: "audio", url: audioUrl, format: audioResponse.format })}\n\n`);
            
            // Update audio generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "audio", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("Audio generation failed:", error);
            // Update audio generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "audio", status: "error" })}\n\n`);
          }
        }

        // Generate video if needed
        if (shouldGenerateVideo) {
          try {
            // Update video generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "video", status: "running" })}\n\n`);
            
            const { generateVideo } = await import("./generationEngine");
            const videoResponse = await generateVideo(message);
            const videoUrl = videoResponse.url;
            res.write(`data: ${JSON.stringify({ type: "video", url: videoUrl })}\n\n`);
            
            // Update video generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "video", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("Video generation failed:", error);
            // Update video generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "video", status: "error" })}\n\n`);
          }
        }

        // Generate WebApp if needed
        if (shouldGenerateWebApp) {
          try {
            // Update app generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "app", status: "running" })}\n\n`);
            
            const { generateWebApp } = await import("./generationEngine");
            const appResponse = await generateWebApp(message);
            webAppUrl = appResponse.url;
            res.write(`data: ${JSON.stringify({ type: "webapp", url: webAppUrl, code: appResponse.code })}\n\n`);
            
            // Update app generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "app", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("WebApp generation failed:", error);
            // Update app generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "app", status: "error" })}\n\n`);
          }
        }

        // Generate Game if needed
        if (shouldGenerateGame) {
          try {
            // Update game generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "game", status: "running" })}\n\n`);
            
            const { generateGame } = await import("./generationEngine");
            const gameResponse = await generateGame(message);
            gameUrl = gameResponse.url;
            res.write(`data: ${JSON.stringify({ type: "game", url: gameUrl, code: gameResponse.code })}\n\n`);
            
            // Update game generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "game", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("Game generation failed:", error);
            // Update game generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "game", status: "error" })}\n\n`);
          }
        }

        // Generate PDF if needed
        if (shouldGeneratePDF) {
          try {
            // Update PDF generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "pdf", status: "running" })}\n\n`);
            
            const { generatePDF } = await import("./generationEngine");
            const pdfResponse = await generatePDF("Generated Document", fullResponse);
            pdfUrl = pdfResponse.url;
            res.write(`data: ${JSON.stringify({ type: "pdf", url: pdfUrl })}\n\n`);
            
            // Update PDF generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "pdf", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("PDF generation failed:", error);
            // Update PDF generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "pdf", status: "error" })}\n\n`);
          }
        }

        // Generate CSV if needed
        if (shouldGenerateCSV) {
          try {
            // Update CSV generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "csv", status: "running" })}\n\n`);
            
            const { generateCSV } = await import("./generationEngine");
            const csvResponse = await generateCSV("Data", fullResponse);
            csvUrl = csvResponse.url;
            res.write(`data: ${JSON.stringify({ type: "csv", url: csvUrl })}\n\n`);
            
            // Update CSV generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "csv", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("CSV generation failed:", error);
            // Update CSV generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "csv", status: "error" })}\n\n`);
          }
        }

        // Generate PowerPoint if needed
        if (shouldGeneratePPT) {
          try {
            // Update PPT generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "slides", status: "running" })}\n\n`);
            
            const { generatePowerPoint } = await import("./generationEngine");
            const slides = fullResponse.split('\n\n').filter(s => s.trim());
            const pptResponse = await generatePowerPoint("Presentation", slides);
            pptUrl = pptResponse.url;
            res.write(`data: ${JSON.stringify({ type: "ppt", url: pptUrl })}\n\n`);
            
            // Update PPT generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "slides", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("PowerPoint generation failed:", error);
            // Update PPT generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "slides", status: "error" })}\n\n`);
          }
        }

        // Generate Website if needed
        if (shouldGenerateWebsite) {
          try {
            // Update website generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "website", status: "running" })}\n\n`);
            
            const { generateWebsite } = await import("./generationEngine");
            const websiteResponse = await generateWebsite(message);
            websiteUrl = websiteResponse.url;
            res.write(`data: ${JSON.stringify({ type: "website", url: websiteUrl, code: websiteResponse.code })}\n\n`);
            
            // Update website generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "website", status: "completed" })}\n\n`);
          } catch (error) {
            console.error("Website generation failed:", error);
            // Update website generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "website", status: "error" })}\n\n`);
          }
        }

        // Generate Python code if needed
        if (shouldGeneratePython) {
          try {
            // Update Python code generation task status to running
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "python", status: "running" })}

`);
            
            // Generate Python code using LLM
            const pythonPrompt = `ユーザーのリクエストに基づいて、実行可能なPythonコードを生成してください。
            
リクエスト: ${message}

以下のルールに従ってください:
1. 完全で実行可能なコードを生成する
2. 必要なimportはすべて含める
3. コメントを日本語で追加する
4. エラーハンドリングを含める
5. 出力結果が明確になるようにprintを使用する

コードのみを返してください。説明は不要です。`;
            
            let pythonCodeResponse = "";
            await streamLLM(
              {
                messages: [
                  { role: "system", content: "あなたはPythonコード生成の専門家です。ユーザーのリクエストに基づいて、実行可能で安全なPythonコードを生成します。" },
                  { role: "user", content: pythonPrompt },
                ],
              },
              (chunk) => {
                pythonCodeResponse += chunk;
              }
            );
            
            pythonCode = pythonCodeResponse;
            res.write(`data: ${JSON.stringify({ type: "python", code: pythonCode })}

`);
            
            // Update Python code generation task status to completed
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "python", status: "completed" })}

`);
          } catch (error) {
            console.error("Python code generation failed:", error);
            // Update Python code generation task status to error
            res.write(`data: ${JSON.stringify({ type: "task-status", taskType: "python", status: "error" })}

`);
          }
        }

        // Save the full response
        await addChatMessage(sessionId, "assistant", fullResponse, imageUrl);

        // Send completion signal
        res.write(`data: ${JSON.stringify({ type: "done" })}\n\n`);
      } catch (error) {
        console.error("Streaming error:", error);
        res.write(`data: ${JSON.stringify({ type: "error", error: "Streaming failed" })}\n\n`);
      }

      res.end();
    } catch (error) {
      console.error("Chat stream error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }
  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
