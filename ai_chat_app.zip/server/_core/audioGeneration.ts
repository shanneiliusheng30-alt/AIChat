/**
 * Audio Generation Service
 * Converts text to speech using Google Cloud Text-to-Speech API
 */

import { ENV } from "./env";
import { storagePut } from "../storage";

export interface AudioGenerationRequest {
  text: string;
  language?: string;
  voice?: string;
}

export interface AudioGenerationResponse {
  url: string;
  format: string;
  duration?: number;
}

/**
 * Generate audio from text using Google Cloud Text-to-Speech API
 */
export async function generateAudio(
  request: AudioGenerationRequest
): Promise<AudioGenerationResponse> {
  try {
    // Use Manus Forge API which provides access to Google Cloud TTS
    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
      throw new Error("Audio generation API credentials not configured");
    }

    // Call the Manus Forge API for text-to-speech (OpenAI TTS compatible)
    const baseUrl = ENV.forgeApiUrl.endsWith("/") ? ENV.forgeApiUrl : `${ENV.forgeApiUrl}/`;
    const response = await fetch(`${baseUrl}v1/audio/speech`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${ENV.forgeApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "tts-1-hd",
        input: request.text,
        voice: request.voice || "nova",
        response_format: "mp3",
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("TTS API error:", error);
      throw new Error(`Audio generation failed: ${response.status} ${error}`);
    }

    // Response is audio binary data
    const audioBuffer = await response.arrayBuffer();
    
    if (!audioBuffer || audioBuffer.byteLength === 0) {
      throw new Error("Empty audio response received");
    }
    
    // Upload to storage
    const timestamp = Date.now();
    const filename = `audio_${timestamp}.mp3`;
    const { url } = await storagePut(
      `audio/${filename}`,
      Buffer.from(audioBuffer),
      "audio/mpeg"
    );

    return {
      url,
      format: "mp3",
      duration: undefined,
    };
  } catch (error) {
    console.error("Audio generation error:", error);
    throw error;
  }
}

/**
 * Generate audio with streaming support
 */
export async function generateAudioStream(
  request: AudioGenerationRequest,
  onChunk?: (chunk: Uint8Array) => void
): Promise<AudioGenerationResponse> {
  try {
    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
      throw new Error("Audio generation API credentials not configured");
    }

    const baseUrl = ENV.forgeApiUrl.endsWith("/") ? ENV.forgeApiUrl : `${ENV.forgeApiUrl}/`;
    const response = await fetch(`${baseUrl}v1/audio/speech`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${ENV.forgeApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "tts-1-hd",
        input: request.text,
        voice: request.voice || "nova",
        response_format: "mp3",
      }),
    });

    if (!response.ok) {
      throw new Error("Audio generation failed");
    }

    // Collect audio data
    const chunks: Uint8Array[] = [];
    if (response.body) {
      const reader = response.body.getReader();
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            if (onChunk) onChunk(value);
          }
        }
      } finally {
        reader.releaseLock();
      }
    }

    // Combine chunks and upload
    const audioBuffer = Buffer.concat(chunks.map(c => Buffer.from(c)));
    const timestamp = Date.now();
    const filename = `audio_${timestamp}.mp3`;
    const { url } = await storagePut(
      `audio/${filename}`,
      audioBuffer,
      "audio/mpeg"
    );

    return {
      url,
      format: "mp3",
      duration: undefined,
    };
  } catch (error) {
    console.error("Audio streaming error:", error);
    throw error;
  }
}
