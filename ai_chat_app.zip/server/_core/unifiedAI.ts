/**
 * Unified AI Service - Integrates chat, image generation, slides, and app creation
 * Provides a single interface for multiple content generation capabilities
 */

import { invokeLLM } from "./llm";
import { generateImage } from "./imageGeneration";

export type TaskType = 'text' | 'image' | 'slides' | 'app' | 'audio' | 'video' | 'pdf' | 'game' | 'website' | 'python';

export type TaskProgress = {
  type: TaskType;
  name: string;
  icon: string;
  status: 'pending' | 'running' | 'completed' | 'error';
};

export type UnifiedAIResponse = {
  text: string;
  imageUrl?: string;
  shouldGenerateImage: boolean;
  shouldCreateSlides?: boolean;
  shouldCreateApp?: boolean;
  shouldGenerateAudio?: boolean;
  shouldGenerateVideo?: boolean;
  shouldGeneratePDF?: boolean;
  shouldCreateGame?: boolean;
  shouldCreateWebsite?: boolean;
  shouldGeneratePython?: boolean;
  slideTopic?: string;
  appDescription?: string;
  audioText?: string;
  videoDescription?: string;
  pdfContent?: string;
  gameDescription?: string;
  websiteDescription?: string;
  pythonCode?: string;
  detectedTasks?: TaskProgress[];
};

/**
 * Detect which tasks should be executed based on the user's prompt
 */
export function detectTasks(userContent: string): TaskProgress[] {
  const tasks: TaskProgress[] = [];
  
  // Always include text generation
  tasks.push({
    type: 'text',
    name: 'テキスト生成',
    icon: '✨',
    status: 'pending',
  });
  
  // Check for image generation
  const imageKeywords = /(画像|描画|絵|画を描画|image|draw|create|generate|picture|photo|illustration|design)/i;
  if (imageKeywords.test(userContent)) {
    tasks.push({
      type: 'image',
      name: '画像生成',
      icon: '🖼',
      status: 'pending',
    });
  }
  
  // Check for slide creation
  const slideKeywords = /(スライド|プレゼンテーション|slides?|presentation)/i;
  if (slideKeywords.test(userContent)) {
    tasks.push({
      type: 'slides',
      name: 'スライド作成',
      icon: '📊',
      status: 'pending',
    });
  }
  
  // Check for app creation
  const appKeywords = /(アプリ|アプリを作成|ウェブサイト|ダッシュボード|app|application|tool|create)/i;
  if (appKeywords.test(userContent) && !slideKeywords.test(userContent)) {
    tasks.push({
      type: 'app',
      name: 'Webアプリ作成',
      icon: '🚀',
      status: 'pending',
    });
  }
  
  // Check for audio generation
  const audioKeywords = /(音声|音声を生成|音声を作成|audio|voice|speech|narration|generate voice)/i;
  if (audioKeywords.test(userContent)) {
    tasks.push({
      type: 'audio',
      name: '音声生成',
      icon: '🎵',
      status: 'pending',
    });
  }
  
  // Check for video generation
  const videoKeywords = /(動画|動画を作成|動画を生成|video|movie|film|generate video)/i;
  if (videoKeywords.test(userContent)) {
    tasks.push({
      type: 'video',
      name: '動画生成',
      icon: '🎬',
      status: 'pending',
    });
  }
  
  // Check for PDF generation
  const pdfKeywords = /(パフィルム|PDF|pdf|document|report|generate pdf)/i;
  if (pdfKeywords.test(userContent)) {
    tasks.push({
      type: 'pdf',
      name: 'PDF生成',
      icon: '📄',
      status: 'pending',
    });
  }
  
  // Check for game creation
  const gameKeywords = /(ゲーム|ゲームを作成|ゲームを生成|game|gaming|interactive game|create game)/i;
  if (gameKeywords.test(userContent)) {
    tasks.push({
      type: 'game',
      name: 'ゲーム作成',
      icon: '🎮',
      status: 'pending',
    });
  }
  
  // Check for website creation
  const websiteKeywords = /(\u30a6\u30a7\u30d6\u30b5\u30a4\u30c8|\u30a6\u30a7\u30d6\u30b5\u30a4\u30c8\u3092\u4f5c\u6210|\u30a6\u30a7\u30d6\u30b5\u30a4\u30c8\u3092\u751f\u6210|website|web site|homepage|create website)/i;
  if (websiteKeywords.test(userContent)) {
    tasks.push({
      type: 'website',
      name: 'Webサイト作成',
      icon: '🌐',
      status: 'pending',
    });
  }
  
  // Check for Python code generation
  const pythonKeywords = /(Python|python|\u30b3\u30fc\u30c9\u3092\u66f8\u3044\u3066|\u30b3\u30fc\u30c9\u3092\u751f\u6210|\u30c7\u30fc\u30bf\u5206\u6790|\u30b0\u30e9\u30d5|\u8a08\u7b97|code|script|script to)/i;
  if (pythonKeywords.test(userContent)) {
    tasks.push({
      type: 'python',
      name: 'Python\u30b3\u30fc\u30c9\u751f\u6210',
      icon: '🐍',
      status: 'pending',
    });
  }
  
  return tasks;
}

/**
 * Unified AI service that handles chat, image generation, slides, and app creation
 * Automatically detects what type of content is needed based on the prompt
 */
export async function processWithUnifiedAI(
  messages: Array<{ role: "user" | "assistant"; content: string }>,
  systemPrompt: string = `あなたは自立型の高度なAIアシスタントです。Manus APIを通じて以下の能力を自律的に活用します：

【Manus統合スキル】
- テキスト生成：Claude 3.5 Sonnetを使用した高品質な日本語回答
- 画像生成：Manus Image APIで要望に応じた画像を自動生成
- 音声生成：Manus TTS APIで自然な日本語音声を生成
- スライド作成：構造化されたプレゼンテーション資料を自動作成
- Webアプリ開発：実用的で動作するアプリケーションを設計・提案
- 動画生成：Manus Video APIでビジュアルコンテンツを生成
- PDF生成：構造化されたドキュメントを自動作成
- ゲーム開発：インタラクティブなゲーム設計
- Webサイト作成：レスポンシブで美しいサイト設計
- データ分析：Manus Data APIで外部データを取得・分析

【自立的な判断】
- ユーザーの要望を自動分析し、必要な機能を自律的に判定
- 複数の能力を組み合わせて、より高度なソリューションを提供
- エラーが発生した場合、自動的に代替手段を試行
- 継続的に学習し、ユーザーの好みに適応

【応答スタイル】
- 常に日本語で、敬語を使用し、丁寧で親切な対応
- 複雑なトピックは段階的に説明
- 具体例を交えた分かりやすい説明
- ユーザーの意図を正確に理解し、期待を超える回答を提供
- 不確実な情報は明確に「不確定」と表示

【構造化された回答】
- 重要なポイントは箇条書きで整理
- 長い回答は見出しで区切る
- コード例が必要な場合は、コードブロックで提示
- 参考資料や次のステップを提案

【ユーザー中心のアプローチ】
- ユーザーの質問の背景にあるニーズを理解
- 単なる質問への回答ではなく、問題解決を支援
- フォローアップ質問を促す
- 継続的な改善を心がける
- 自動的に最適なManus APIを選択して実行`
): Promise<UnifiedAIResponse> {
  // Get AI response with high-performance model
  const response = await invokeLLM({
    model: "claude-3-5-sonnet-20241022", // Use high-performance model for better quality
    messages: [
      { role: "system", content: systemPrompt },
      ...messages,
    ],
  });

  const assistantMessage =
    typeof response.choices[0].message.content === "string"
      ? response.choices[0].message.content
      : "";

  // Check if image generation is needed based on the last user message
  const lastUserMessage = messages[messages.length - 1];
  const userContent = lastUserMessage?.content || "";

  const imageKeywords =
    /(\u753b\u50cf|\u63cf\u753b|\u7d75|\u753b\u3092\u63cf\u753b|image|draw|create|generate|picture|photo|illustration|design)/i;
  const shouldGenerateImage = imageKeywords.test(userContent);
  
  // Check if slide creation is needed
  const slideKeywords = /(\u30b9\u30e9\u30a4\u30c9|\u30d7\u30ec\u30bc\u30f3\u30c6\u30fc\u30b7\u30e7\u30f3|slides?|presentation)/i;
  const shouldCreateSlides = slideKeywords.test(userContent);
  
  // Check if app creation is needed
  const appKeywords = /(\u30a2\u30d7\u30ea|\u30a2\u30d7\u30ea\u3092\u4f5c\u6210|\u30a6\u30a7\u30d6\u30b5\u30a4\u30c8|\u30c0\u30c3\u30b7\u30e5\u30dc\u30fc\u30c9|app|application|tool|create)/i;
  const shouldCreateApp = appKeywords.test(userContent) && !shouldCreateSlides && !slideKeywords.test(userContent);

  // Check if audio generation is needed
  const audioKeywords = /(\u97f3\u58f0|\u97f3\u58f0\u3092\u751f\u6210|\u97f3\u58f0\u3092\u4f5c\u6210|audio|voice|speech|narration|generate voice)/i;
  const shouldGenerateAudio = audioKeywords.test(userContent);

  // Check if video generation is needed
  const videoKeywords = /(\u52d5\u753b|\u52d5\u753b\u3092\u4f5c\u6210|\u52d5\u753b\u3092\u751f\u6210|video|movie|film|generate video)/i;
  const shouldGenerateVideo = videoKeywords.test(userContent);

  // Check if PDF generation is needed
  const pdfKeywords = /(\u30d1\u30d5\u30a3\u30eb\u30e0|PDF|pdf|document|report|generate pdf)/i;
  const shouldGeneratePDF = pdfKeywords.test(userContent);

  // Check if game creation is needed
  const gameKeywords = /(\u30b2\u30fc\u30e0|\u30b2\u30fc\u30e0\u3092\u4f5c\u6210|\u30b2\u30fc\u30e0\u3092\u751f\u6210|game|gaming|interactive game|create game)/i;
  const shouldCreateGame = gameKeywords.test(userContent);

  // Check if website creation is needed
  const websiteKeywords = /(\u30a6\u30a7\u30d6\u30b5\u30a4\u30c8|\u30a6\u30a7\u30d6\u30b5\u30a4\u30c8\u3092\u4f5c\u6210|\u30a6\u30a7\u30d6\u30b5\u30a4\u30c8\u3092\u751f\u6210|website|web site|homepage|create website)/i;
  const shouldCreateWebsite = websiteKeywords.test(userContent);
  
  // Check if Python code generation is needed
  const pythonKeywords = /(Python|python|\u30b3\u30fc\u30c9\u3092\u66f8\u3044\u3066|\u30b3\u30fc\u30c9\u3092\u751f\u6210|\u30c7\u30fc\u30bf\u5206\u6790|\u30b0\u30e9\u30d5|\u8a08\u7b97|code|script|script to)/i;
  const shouldGeneratePython = pythonKeywords.test(userContent);

  let imageUrl: string | undefined = undefined;

  if (shouldGenerateImage && !shouldCreateSlides && !shouldCreateApp && !shouldGenerateAudio && !shouldGenerateVideo && !shouldGeneratePDF && !shouldCreateGame && !shouldCreateWebsite) {
    try {
      // Use the user's message as the image prompt
      const imageResponse = await generateImage({ prompt: userContent });
      imageUrl = imageResponse.url;
    } catch (error) {
      console.error("Image generation failed:", error);
      // Continue without image if generation fails
    }
  }

  // Detect tasks to be executed
  const detectedTasks = detectTasks(userContent);

  // Generate Python code if needed
  let pythonCode: string | undefined = undefined;
  if (shouldGeneratePython) {
    try {
      const pythonPrompt = `ユーザーのリクエストに基づいて、実行可能なPythonコードを生成してください。
      
リクエスト: ${userContent}

以下のルールに従ってください:
1. 完全で実行可能なコードを生成する
2. 必要なimportはすべて含める
3. コメントを日本語で追加する
4. エラーハンドリングを含める
5. 出力結果が明確になるようにprintを使用する

コードのみを返してください。説明は不要です。`;
      
      const pythonResponse = await invokeLLM({
        model: "claude-3-5-sonnet-20241022",
        messages: [
          { role: "system", content: "あなたはPythonコード生成の専門家です。ユーザーのリクエストに基づいて、実行可能で安全なPythonコードを生成します。" },
          { role: "user", content: pythonPrompt },
        ],
      });
      
      pythonCode = typeof pythonResponse.choices[0].message.content === "string"
        ? pythonResponse.choices[0].message.content
        : "";
    } catch (error) {
      console.error("Python code generation failed:", error);
    }
  }

  return {
    text: assistantMessage,
    imageUrl,
    shouldGenerateImage: shouldGenerateImage && !shouldCreateSlides && !shouldCreateApp && !shouldGenerateAudio && !shouldGenerateVideo && !shouldGeneratePDF && !shouldCreateGame && !shouldCreateWebsite && !shouldGeneratePython,
    shouldCreateSlides,
    shouldCreateApp,
    shouldGenerateAudio,
    shouldGenerateVideo,
    shouldGeneratePDF,
    shouldCreateGame,
    shouldCreateWebsite,
    shouldGeneratePython,
    slideTopic: shouldCreateSlides ? userContent : undefined,
    appDescription: shouldCreateApp ? userContent : undefined,
    audioText: shouldGenerateAudio ? userContent : undefined,
    videoDescription: shouldGenerateVideo ? userContent : undefined,
    pdfContent: shouldGeneratePDF ? userContent : undefined,
    gameDescription: shouldCreateGame ? userContent : undefined,
    websiteDescription: shouldCreateWebsite ? userContent : undefined,
    pythonCode,
    detectedTasks,
  };
}

/**
 * Process a single user message with unified AI
 * Handles text response, image generation, slides, and app creation
 */
export async function processUserMessage(
  userMessage: string,
  conversationHistory: Array<{ role: "user" | "assistant"; content: string }>
): Promise<UnifiedAIResponse> {
  const messages = [
    ...conversationHistory,
    { role: "user" as const, content: userMessage },
  ];

  return processWithUnifiedAI(messages);
}
