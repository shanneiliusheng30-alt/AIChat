import { describe, it, expect } from 'vitest';
import { executePythonCode, isSafeCode } from './pythonExecutor';

describe('Python Executor', () => {
  describe('isSafeCode', () => {
    it('should allow safe Python code', () => {
      const result = isSafeCode('print("Hello, World!")');
      expect(result.safe).toBe(true);
    });

    it('should allow mathematical operations', () => {
      const result = isSafeCode('result = 2 + 2\nprint(result)');
      expect(result.safe).toBe(true);
    });

    it('should allow list operations', () => {
      const result = isSafeCode('numbers = [1, 2, 3]\nfor n in numbers:\n    print(n)');
      expect(result.safe).toBe(true);
    });

    it('should block os.system', () => {
      const result = isSafeCode('os.system("rm -rf /")');
      expect(result.safe).toBe(false);
      expect(result.reason).toContain('危険な');
    });

    it('should block subprocess', () => {
      const result = isSafeCode('import subprocess\nsubprocess.run(["ls"])');
      expect(result.safe).toBe(false);
    });

    it('should block eval', () => {
      const result = isSafeCode('eval("__import__(\'os\').system(\'ls\')")');
      expect(result.safe).toBe(false);
    });

    it('should block exec', () => {
      const result = isSafeCode('exec("print(\'test\')")');
      expect(result.safe).toBe(false);
    });

    it('should block __import__', () => {
      const result = isSafeCode('__import__("os").system("ls")');
      expect(result.safe).toBe(false);
    });

    it('should block open for file operations', () => {
      const result = isSafeCode('with open("/etc/passwd") as f:\n    print(f.read())');
      expect(result.safe).toBe(false);
    });

    it('should be case insensitive', () => {
      const result = isSafeCode('IMPORT OS');
      expect(result.safe).toBe(false);
    });
  });

  describe('executePythonCode', () => {
    it('should execute simple print statement', async () => {
      const result = await executePythonCode('print("Hello, World!")');
      expect(result.success).toBe(true);
      expect(result.output).toContain('Hello, World!');
      expect(result.executionTime).toBeDefined();
    });

    it('should execute mathematical operations', async () => {
      const result = await executePythonCode('print(2 + 2)');
      expect(result.success).toBe(true);
      expect(result.output).toContain('4');
    });

    it('should execute list comprehension', async () => {
      const result = await executePythonCode('result = [x*2 for x in range(5)]\nprint(result)');
      expect(result.success).toBe(true);
      expect(result.output).toContain('[0, 2, 4, 6, 8]');
    });

    it('should return error for unsafe code', async () => {
      const result = await executePythonCode('os.system("ls")');
      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });

    it('should handle Python syntax errors', async () => {
      const result = await executePythonCode('print("unclosed string');
      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });

    it('should handle runtime errors', async () => {
      const result = await executePythonCode('print(1/0)');
      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });

    it('should execute string operations', async () => {
      const result = await executePythonCode('text = "Hello"\nprint(text.upper())');
      expect(result.success).toBe(true);
      expect(result.output).toContain('HELLO');
    });

    it('should execute dictionary operations', async () => {
      const result = await executePythonCode('d = {"a": 1, "b": 2}\nprint(d["a"])');
      expect(result.success).toBe(true);
      expect(result.output).toContain('1');
    });

    it('should handle multiple print statements', async () => {
      const result = await executePythonCode('print("Line 1")\nprint("Line 2")\nprint("Line 3")');
      expect(result.success).toBe(true);
      expect(result.output).toContain('Line 1');
      expect(result.output).toContain('Line 2');
      expect(result.output).toContain('Line 3');
    });

    it('should handle loop execution', async () => {
      const result = await executePythonCode('for i in range(3):\n    print(i)');
      expect(result.success).toBe(true);
      expect(result.output).toContain('0');
      expect(result.output).toContain('1');
      expect(result.output).toContain('2');
    });

    it('should handle function definition and call', async () => {
      const result = await executePythonCode('def add(a, b):\n    return a + b\nprint(add(3, 4))');
      expect(result.success).toBe(true);
      expect(result.output).toContain('7');
    });

    it('should handle conditional statements', async () => {
      const result = await executePythonCode('x = 10\nif x > 5:\n    print("Greater")\nelse:\n    print("Less")');
      expect(result.success).toBe(true);
      expect(result.output).toContain('Greater');
    });

    it('should handle JSON operations', async () => {
      const result = await executePythonCode('import json\ndata = {"name": "test"}\nprint(json.dumps(data))');
      expect(result.success).toBe(true);
      expect(result.output).toContain('name');
    });

    it('should handle datetime operations', async () => {
      const result = await executePythonCode('from datetime import datetime\nprint(datetime.now().year)');
      expect(result.success).toBe(true);
      expect(result.output).toContain('202');
    });
  });
});
