import Stripe from "stripe";
import { Request, Response } from "express";
import {
  handlePaymentSuccess,
  handleSubscriptionCreated,
  handleSubscriptionUpdated,
} from "./checkout";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || "";

/**
 * Verify and process Stripe webhook events
 */
export async function handleStripeWebhook(req: Request, res: Response) {
  const sig = req.headers["stripe-signature"] as string;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err: any) {
    console.error("[Webhook] Signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle test events
  if (event.id.startsWith("evt_test_")) {
    console.log("[Webhook] Test event detected, returning verification response");
    return res.json({
      verified: true,
    });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutSessionCompleted(session);
        break;
      }

      case "customer.subscription.created": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionCreatedEvent(subscription);
        break;
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdatedEvent(subscription);
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionDeletedEvent(subscription);
        break;
      }

      case "payment_intent.succeeded": {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        console.log("[Webhook] Payment intent succeeded:", paymentIntent.id);
        break;
      }

      default:
        console.log("[Webhook] Unhandled event type:", event.type);
    }

    res.json({ received: true });
  } catch (error) {
    console.error("[Webhook] Error processing event:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
}

/**
 * Handle checkout.session.completed event
 */
async function handleCheckoutSessionCompleted(session: Stripe.Checkout.Session) {
  const userId = parseInt(session.client_reference_id || "0");
  const stripePriceId = (session.line_items?.data[0]?.price?.id || "") as string;

  if (!userId || !stripePriceId) {
    console.error("[Webhook] Missing userId or stripePriceId in session");
    return;
  }

  // For payment mode (one-time purchases)
  if (session.mode === "payment" && session.payment_intent) {
    const paymentIntent = session.payment_intent as Stripe.PaymentIntent;

    await handlePaymentSuccess(
      userId,
      stripePriceId,
      paymentIntent.id,
      paymentIntent.amount,
      paymentIntent.currency
    );

    console.log("[Webhook] Payment completed for user:", userId);
  }
}

/**
 * Handle customer.subscription.created event
 */
async function handleSubscriptionCreatedEvent(subscription: Stripe.Subscription) {
  const userId = parseInt(subscription.metadata?.user_id || "0");
  const stripePriceId = (subscription.items.data[0]?.price.id || "") as string;

  if (!userId || !stripePriceId) {
    console.error("[Webhook] Missing userId or stripePriceId in subscription");
    return;
  }

  await handleSubscriptionCreated(
    userId,
    subscription.id,
    stripePriceId,
    subscription.status,
    (subscription as any).current_period_start,
    (subscription as any).current_period_end
  );

  console.log("[Webhook] Subscription created for user:", userId);
}

/**
 * Handle customer.subscription.updated event
 */
async function handleSubscriptionUpdatedEvent(subscription: Stripe.Subscription) {
  const canceledAt = subscription.canceled_at;

  await handleSubscriptionUpdated(
    subscription.id,
    subscription.status,
    (subscription as any).current_period_start,
    (subscription as any).current_period_end,
    canceledAt || undefined
  );

  console.log("[Webhook] Subscription updated:", subscription.id);
}

/**
 * Handle customer.subscription.deleted event
 */
async function handleSubscriptionDeletedEvent(subscription: Stripe.Subscription) {
  await handleSubscriptionUpdated(
    subscription.id,
    "canceled",
    (subscription as any).current_period_start,
    (subscription as any).current_period_end,
    subscription.canceled_at || undefined
  );

  console.log("[Webhook] Subscription deleted:", subscription.id);
}
