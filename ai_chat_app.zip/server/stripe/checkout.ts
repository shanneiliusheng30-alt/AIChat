import Stripe from "stripe";
import { getDb } from "../db";
import { payments, userSubscriptions } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

/**
 * Create a Checkout Session for one-time purchases
 */
export async function createCheckoutSession(
  userId: number,
  userEmail: string,
  userName: string,
  stripePriceId: string,
  origin: string
) {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price: stripePriceId,
          quantity: 1,
        },
      ],
      mode: "payment",
      customer_email: userEmail,
      client_reference_id: userId.toString(),
      metadata: {
        user_id: userId.toString(),
        customer_email: userEmail,
        customer_name: userName,
      },
      success_url: `${origin}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/payment-cancel`,
      allow_promotion_codes: true,
    });

    return session;
  } catch (error) {
    console.error("[Stripe] Failed to create checkout session:", error);
    throw error;
  }
}

/**
 * Create a Checkout Session for subscriptions
 */
export async function createSubscriptionCheckoutSession(
  userId: number,
  userEmail: string,
  userName: string,
  stripePriceId: string,
  origin: string
) {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price: stripePriceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      customer_email: userEmail,
      client_reference_id: userId.toString(),
      metadata: {
        user_id: userId.toString(),
        customer_email: userEmail,
        customer_name: userName,
      },
      success_url: `${origin}/subscription-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/subscription-cancel`,
      allow_promotion_codes: true,
    });

    return session;
  } catch (error) {
    console.error("[Stripe] Failed to create subscription checkout session:", error);
    throw error;
  }
}

/**
 * Handle successful payment
 */
export async function handlePaymentSuccess(
  userId: number,
  stripePriceId: string,
  stripePaymentIntentId: string,
  amount: number,
  currency: string
) {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    
    await db.insert(payments).values({
      userId,
      stripePaymentIntentId,
      stripePriceId,
      amount,
      currency,
      status: "succeeded",
    });

    console.log("[Stripe] Payment recorded successfully for user:", userId);
  } catch (error) {
    console.error("[Stripe] Failed to record payment:", error);
    throw error;
  }
}

/**
 * Handle subscription creation
 */
export async function handleSubscriptionCreated(
  userId: number,
  stripeSubscriptionId: string,
  stripePriceId: string,
  status: string,
  currentPeriodStart: number,
  currentPeriodEnd: number
) {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    
    await db.insert(userSubscriptions).values({
      userId,
      stripeSubscriptionId,
      stripePriceId,
      status: status as "active" | "past_due" | "canceled" | "unpaid",
      currentPeriodStart: new Date(currentPeriodStart * 1000),
      currentPeriodEnd: new Date(currentPeriodEnd * 1000),
    });

    console.log("[Stripe] Subscription created for user:", userId);
  } catch (error) {
    console.error("[Stripe] Failed to create subscription:", error);
    throw error;
  }
}

/**
 * Handle subscription update
 */
export async function handleSubscriptionUpdated(
  stripeSubscriptionId: string,
  status: string,
  currentPeriodStart: number,
  currentPeriodEnd: number,
  canceledAt?: number
) {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    
    const updateData: any = {
      status: status as "active" | "past_due" | "canceled" | "unpaid",
      currentPeriodStart: new Date(currentPeriodStart * 1000),
      currentPeriodEnd: new Date(currentPeriodEnd * 1000),
    };

    if (canceledAt) {
      updateData.canceledAt = new Date(canceledAt * 1000);
    }

    await db
      .update(userSubscriptions)
      .set(updateData)
      .where(eq(userSubscriptions.stripeSubscriptionId, stripeSubscriptionId));

    console.log("[Stripe] Subscription updated:", stripeSubscriptionId);
  } catch (error) {
    console.error("[Stripe] Failed to update subscription:", error);
    throw error;
  }
}

/**
 * Get user's active subscription
 */
export async function getUserActiveSubscription(userId: number) {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    
    const result = await db.select().from(userSubscriptions).where(eq(userSubscriptions.userId, userId)).limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Stripe] Failed to get user subscription:", error);
    return null;
  }
}

/**
 * Get user's payment history
 */
export async function getUserPaymentHistory(userId: number) {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    
    const paymentHistory = await db.select().from(payments).where(eq(payments.userId, userId));
    return paymentHistory;
  } catch (error) {
    console.error("[Stripe] Failed to get payment history:", error);
    return [];
  }
}
