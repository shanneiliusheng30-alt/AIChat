import { exec } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import fs from 'fs';
import os from 'os';

const execAsync = promisify(exec);

// 危険なモジュールとコマンドのブロックリスト
const BLOCKED_MODULES = [
  'os.system',
  'os.popen',
  'subprocess',
  'eval',
  '__import__',
  'exec',
  'compile',
  'open',
  'input',
  'raw_input',
];

const BLOCKED_KEYWORDS = [
  'import os',
  'import subprocess',
  'import sys',
  'from os import',
  'from subprocess import',
  '__import__',
  'eval(',
  'exec(',
  'compile(',
];

/**
 * Pythonコードが安全かどうかをチェック
 */
export function isSafeCode(code: string): { safe: boolean; reason?: string } {
  const lowerCode = code.toLowerCase();

  for (const keyword of BLOCKED_KEYWORDS) {
    if (lowerCode.includes(keyword.toLowerCase())) {
      return {
        safe: false,
        reason: `危険なキーワード "${keyword}" が含まれています`,
      };
    }
  }

  for (const module of BLOCKED_MODULES) {
    if (lowerCode.includes(module.toLowerCase())) {
      return {
        safe: false,
        reason: `危険なモジュール "${module}" が含まれています`,
      };
    }
  }

  return { safe: true };
}

/**
 * Pythonコードを実行
 */
export async function executePythonCode(code: string): Promise<{
  success: boolean;
  output?: string;
  error?: string;
  executionTime?: number;
}> {
  // セキュリティチェック
  const safetyCheck = isSafeCode(code);
  if (!safetyCheck.safe) {
    return {
      success: false,
      error: safetyCheck.reason || '安全でないコードです',
    };
  }

  try {
    // 一時ファイルにコードを保存
    const tempDir = os.tmpdir();
    const tempFile = path.join(tempDir, `python_${Date.now()}_${Math.random().toString(36).substr(2, 9)}.py`);

    fs.writeFileSync(tempFile, code, 'utf-8');

    const startTime = Date.now();

    try {
      // Pythonコードを実行（タイムアウト30秒）
      const { stdout, stderr } = await execAsync(`python3 "${tempFile}"`, {
        timeout: 30000,
        maxBuffer: 10 * 1024 * 1024, // 10MB
      });

      const executionTime = Date.now() - startTime;

      // 一時ファイルを削除
      fs.unlinkSync(tempFile);

      if (stderr) {
        return {
          success: false,
          error: stderr,
          executionTime,
        };
      }

      return {
        success: true,
        output: stdout || '(出力なし)',
        executionTime,
      };
    } catch (error) {
      // 一時ファイルを削除
      try {
        fs.unlinkSync(tempFile);
      } catch (e) {
        // ファイル削除失敗は無視
      }

      const executionTime = Date.now() - startTime;

      if (error instanceof Error) {
        // タイムアウトエラー
        if (error.message.includes('ETIMEDOUT')) {
          return {
            success: false,
            error: 'コード実行がタイムアウトしました（30秒以上）',
            executionTime,
          };
        }

        // その他のエラー
        const errorMessage = error.message || 'Unknown error';
        return {
          success: false,
          error: errorMessage,
          executionTime,
        };
      }

      throw error;
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
}
