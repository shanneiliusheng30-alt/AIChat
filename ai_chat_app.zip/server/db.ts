import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, chatSessions, chatMessages, learningItems, InsertChatSession, InsertChatMessage, InsertLearningItem, stripeProducts, stripePrices, userSubscriptions, payments, InsertStripeProduct, InsertStripePrice, InsertUserSubscription, InsertPayment } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Chat session queries
export async function createChatSession(userId: number, title: string, mode: 'chat' | 'learning' = 'chat'): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(chatSessions).values({
    userId,
    title,
    mode,
  });
  
  return (result as any).insertId as number;
}

export async function getChatSessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(chatSessions)
    .where(eq(chatSessions.userId, userId))
    .orderBy(desc(chatSessions.updatedAt));
}

export async function getChatSession(sessionId: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(chatSessions)
    .where(eq(chatSessions.id, sessionId));
  
  if (result.length === 0 || result[0].userId !== userId) return undefined;
  return result[0];
}

export async function updateChatSessionTitle(sessionId: number, userId: number, title: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  
  const session = await getChatSession(sessionId, userId);
  if (!session) return false;
  
  await db.update(chatSessions)
    .set({ title, updatedAt: new Date() })
    .where(eq(chatSessions.id, sessionId));
  
  return true;
}

export async function deleteChatSession(sessionId: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  
  const session = await getChatSession(sessionId, userId);
  if (!session) return false;
  
  // Delete messages first
  await db.delete(chatMessages).where(eq(chatMessages.sessionId, sessionId));
  // Delete learning items
  await db.delete(learningItems).where(eq(learningItems.sessionId, sessionId));
  // Delete session
  await db.delete(chatSessions).where(eq(chatSessions.id, sessionId));
  
  return true;
}

// Chat message queries
export async function addChatMessage(sessionId: number, role: 'user' | 'assistant', content: string, imageUrl?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(chatMessages).values({
    sessionId,
    role,
    content,
    imageUrl,
  });
  
  return (result as any).insertId as number;
}

export async function getChatMessages(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(chatMessages)
    .where(eq(chatMessages.sessionId, sessionId))
    .orderBy(chatMessages.createdAt);
}

// Learning item queries
export async function createLearningItem(sessionId: number, type: 'flashcard' | 'problem' | 'explanation', question: string, answer?: string, explanation?: string, difficulty: 'easy' | 'medium' | 'hard' = 'medium') {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(learningItems).values({
    sessionId,
    type,
    question,
    answer,
    explanation,
    difficulty,
  });
  
  return (result as any).insertId as number;
}

export async function getLearningItems(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(learningItems)
    .where(eq(learningItems.sessionId, sessionId));
}


/**
 * Get recent conversation context (last N messages for better context)
 */
export async function getRecentConversationContext(sessionId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get conversation context: database not available");
    return [];
  }

  try {
    const messages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.sessionId, sessionId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);

    // Reverse to get chronological order
    return messages.reverse();
  } catch (error) {
    console.error("[Database] Failed to get conversation context:", error);
    return [];
  }
}

/**
 * Extract key topics from conversation history
 */
export function extractConversationTopics(messages: Array<{ content: string; role: string }>): string[] {
  const topics = new Set<string>();
  
  messages.forEach(msg => {
    // Extract common keywords and topics
    const keywords = msg.content.match(/[ぁ-ん一-龯ァ-ヴー々〆〤a-zA-Z]+/g) || [];
    keywords.forEach(keyword => {
      if (keyword.length > 2) {
        topics.add(keyword);
      }
    });
  });
  
  return Array.from(topics).slice(0, 5); // Return top 5 topics
}


// ===== Stripe Payment Helpers =====

/**
 * Get all active Stripe products
 */
export async function getStripeProducts() {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(stripeProducts).where(eq(stripeProducts.active, 1));
  } catch (error) {
    console.error("[Database] Failed to get Stripe products:", error);
    return [];
  }
}

/**
 * Get prices for a specific product
 */
export async function getStripePrices(stripeProductId: string) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(stripePrices)
      .where(and(
        eq(stripePrices.stripeProductId, stripeProductId),
        eq(stripePrices.active, 1)
      ));
  } catch (error) {
    console.error("[Database] Failed to get Stripe prices:", error);
    return [];
  }
}

/**
 * Get user's active subscription
 */
export async function getUserSubscription(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  try {
    const subscription = await db.select().from(userSubscriptions)
      .where(and(
        eq(userSubscriptions.userId, userId),
        eq(userSubscriptions.status, "active")
      ))
      .limit(1);
    
    return subscription[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get user subscription:", error);
    return null;
  }
}

/**
 * Create or update user subscription
 */
export async function upsertUserSubscription(data: InsertUserSubscription) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert subscription: database not available");
    return;
  }
  
  try {
    await db.insert(userSubscriptions)
      .values(data)
      .onDuplicateKeyUpdate({
        set: {
          status: data.status,
          currentPeriodStart: data.currentPeriodStart,
          currentPeriodEnd: data.currentPeriodEnd,
          updatedAt: new Date(),
        }
      });
  } catch (error) {
    console.error("[Database] Failed to upsert subscription:", error);
  }
}

/**
 * Record a payment
 */
export async function recordPayment(data: InsertPayment) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot record payment: database not available");
    return;
  }
  
  try {
    await db.insert(payments).values(data);
  } catch (error) {
    console.error("[Database] Failed to record payment:", error);
  }
}

/**
 * Get user's payment history
 */
export async function getUserPayments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(payments)
      .where(eq(payments.userId, userId));
  } catch (error) {
    console.error("[Database] Failed to get user payments:", error);
    return [];
  }
}


/**
 * Update user subscription after successful payment
 */
export async function updateUserSubscription(userId: number, stripePriceId: string, stripeSubscriptionId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update subscription: database not available");
    return;
  }
  
  try {
    // Check if subscription exists
    const existing = await db.select().from(userSubscriptions)
      .where(eq(userSubscriptions.userId, userId));
    
    if (existing.length > 0) {
      // Update existing subscription
      await db.update(userSubscriptions)
        .set({
          stripePriceId,
          stripeSubscriptionId,
          status: "active",
          updatedAt: new Date(),
        })
        .where(eq(userSubscriptions.userId, userId));
    } else {
      // Create new subscription
      await db.insert(userSubscriptions).values({
        userId,
        stripePriceId,
        stripeSubscriptionId,
        status: "active",
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }
  } catch (error) {
    console.error("[Database] Failed to update subscription:", error);
  }
}

