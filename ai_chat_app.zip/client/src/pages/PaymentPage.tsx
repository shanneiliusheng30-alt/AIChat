import { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function PaymentPage() {
  const { user } = useAuth();
  const [selectedPriceId, setSelectedPriceId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch products
  const productsQuery = trpc.payment.getProducts.useQuery();
  const pricesQuery = trpc.payment.getPrices.useQuery(
    { productId: selectedPriceId || "" },
    { enabled: !!selectedPriceId }
  );

  // Fetch user subscription
  const subscriptionQuery = trpc.payment.getUserSubscription.useQuery(
    undefined,
    { enabled: !!user }
  );

  // Create checkout session
  const checkoutMutation = trpc.payment.createCheckoutSession.useMutation({
    onSuccess: (data) => {
      if (data.url) {
        toast.success("チェックアウトページへ移動します");
        window.open(data.url, "_blank");
      }
      setIsLoading(false);
    },
    onError: (error) => {
      console.error("Checkout failed:", error);
      toast.error("チェックアウトセッションの作成に失敗しました");
      setIsLoading(false);
    },
  });

  const handleCheckout = async (priceId: string) => {
    setIsLoading(true);
    await checkoutMutation.mutateAsync({ priceId });
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <p className="text-gray-600 mb-4">ログインしてください</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-4">料金プラン</h1>
        <p className="text-center text-gray-600 mb-12">
          あなたのニーズに合ったプランを選択してください
        </p>

        {/* Current Subscription */}
        {subscriptionQuery.data && (
          <Card className="mb-8 p-6 bg-green-50 border-green-200">
            <p className="text-green-800">
              現在のサブスクリプション: <strong>{subscriptionQuery.data.status}</strong>
            </p>
          </Card>
        )}

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {productsQuery.isLoading ? (
            <div className="flex items-center justify-center col-span-full">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
          ) : productsQuery.data && productsQuery.data.length > 0 ? (
            productsQuery.data.map((product) => (
              <Card
                key={product.stripeProductId}
                className="p-6 hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setSelectedPriceId(product.stripeProductId)}
              >
                <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-4">{product.description}</p>

                {/* Prices for this product */}
                {selectedPriceId === product.stripeProductId &&
                pricesQuery.data ? (
                  <div className="space-y-3">
                    {pricesQuery.data.map((price) => (
                      <div
                        key={price.stripePriceId}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded"
                      >
                        <div>
                          <p className="font-semibold">
                            ${(price.amount / 100).toFixed(2)} {price.currency.toUpperCase()}
                          </p>
                          <p className="text-sm text-gray-600">{price.interval}</p>
                        </div>
                        <Button
                          onClick={() => handleCheckout(price.stripePriceId)}
                          disabled={isLoading}
                          size="sm"
                        >
                          {isLoading ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            "購入"
                          )}
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <Button
                    onClick={() => setSelectedPriceId(product.stripeProductId)}
                    variant="outline"
                    className="w-full"
                  >
                    詳細を見る
                  </Button>
                )}
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center text-gray-600">
              利用可能なプランがありません
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
