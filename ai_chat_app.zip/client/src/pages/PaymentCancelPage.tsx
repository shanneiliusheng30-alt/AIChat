import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";

export default function PaymentCancelPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-red-50 to-white">
      <Card className="p-8 text-center max-w-md">
        <AlertCircle className="w-16 h-16 text-red-600 mx-auto mb-4" />
        <h1 className="text-3xl font-bold text-red-600 mb-2">支払いがキャンセルされました</h1>
        <p className="text-gray-600 mb-6">
          支払い処理がキャンセルされました。もう一度お試しいただくか、別のプランをお選びください。
        </p>
        <div className="space-y-3">
          <Button
            onClick={() => setLocation("/payment")}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            料金プランに戻る
          </Button>
          <Button
            onClick={() => setLocation("/chat")}
            variant="outline"
            className="w-full"
          >
            チャットに戻る
          </Button>
        </div>
      </Card>
    </div>
  );
}
