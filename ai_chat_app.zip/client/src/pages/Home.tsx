import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Sparkles, BookOpen, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-2xl font-bold">
            <Sparkles className="w-8 h-8 text-blue-600" />
            AI アシスタント
          </div>
          {!isAuthenticated && (
            <a href={getLoginUrl()}>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                ログイン
              </Button>
            </a>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-6 py-20 text-center">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          あなたのインテリジェント学習パートナー
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          AI駆動の会話、画像生成、パーソナライズされた学習支援がすべて1つのエレガントなプラットフォームで利用できます。
        </p>
        {!isAuthenticated && (
          <a href={getLoginUrl()}>
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-8 py-6">
              始める
            </Button>
          </a>
        )}
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white border border-gray-200 rounded-lg p-8 hover:border-blue-400 hover:shadow-lg transition-all">
            <Sparkles className="w-12 h-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-bold mb-2 text-gray-900">AI会話</h3>
            <p className="text-gray-600">
              文脈を理解し、思慮深く教育的な応答を提供するインテリジェントなAIアシスタントとチャットします。
            </p>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg p-8 hover:border-purple-400 hover:shadow-lg transition-all">
            <Zap className="w-12 h-12 text-purple-600 mb-4" />
            <h3 className="text-xl font-bold mb-2 text-gray-900">画像生成</h3>
            <p className="text-gray-600">
              テキストの説明から素晴らしい画像を生成し、会話にシームレスに統合します。
            </p>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg p-8 hover:border-green-400 hover:shadow-lg transition-all">
            <BookOpen className="w-12 h-12 text-green-600 mb-4" />
            <h3 className="text-xl font-bold mb-2 text-gray-900">学習支援</h3>
            <p className="text-gray-600">
              フラッシュカード、問題解法、詳細な解説を含むインタラクティブな学習ツールにアクセスします。
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-6xl mx-auto px-6 py-16 text-center">
        <h2 className="text-3xl font-bold mb-4 text-gray-900">学習を変革する準備はできていますか？</h2>
        <p className="text-gray-600 mb-8">より賢く、より効果的な学習のためにAIを活用している数千人のユーザーに参加してください。</p>
        {!isAuthenticated && (
          <a href={getLoginUrl()}>
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-8 py-6">
              今すぐ無料で始める
            </Button>
          </a>
        )}
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-gray-50 mt-20">
        <div className="max-w-6xl mx-auto px-6 py-8 text-center text-gray-600">
          <p>&copy; 2026 AI アシスタント。すべての権利を保有します。</p>
        </div>
      </footer>
    </div>
  );
}
