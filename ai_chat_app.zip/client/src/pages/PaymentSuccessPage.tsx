import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle2 } from "lucide-react";

export default function PaymentSuccessPage() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Auto-redirect after 5 seconds
    const timer = setTimeout(() => {
      setLocation("/chat");
    }, 5000);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-green-50 to-white">
      <Card className="p-8 text-center max-w-md">
        <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
        <h1 className="text-3xl font-bold text-green-600 mb-2">支払い完了</h1>
        <p className="text-gray-600 mb-6">
          ご購入ありがとうございます。すぐにサービスをご利用いただけます。
        </p>
        <Button
          onClick={() => setLocation("/chat")}
          className="w-full bg-blue-600 hover:bg-blue-700"
        >
          チャットに戻る
        </Button>
        <p className="text-sm text-gray-500 mt-4">
          5秒後に自動的にチャットページに移動します...
        </p>
      </Card>
    </div>
  );
}
