import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";

import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Loader2, Plus, Send, Sparkles, BookOpen, Trash2, Edit2, MessageCircle, Menu, X, Paperclip, X as XIcon, ChevronDown, LogOut } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { Streamdown } from "streamdown";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function ChatApp() {
  const { user, logout } = useAuth();
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const [optimisticMessages, setOptimisticMessages] = useState<Array<{ id: string; role: string; content: string; imageUrl?: string; pythonCode?: string; isOptimistic?: boolean; isStreaming?: boolean }>>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isStreaming, setIsStreaming] = useState(false);

  const [renameDialogOpen, setRenameDialogOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [selectedSessionForRename, setSelectedSessionForRename] = useState<number | null>(null);
  const [taskProgressOpen, setTaskProgressOpen] = useState(true);
  const [activeTasks, setActiveTasks] = useState<Array<{ type: string; name: string; icon: string; status: 'pending' | 'running' | 'completed' | 'error' }>>([]);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<{ [key: string]: string }>({});
  
  // Code generation state
  const [generatedCode, setGeneratedCode] = useState<string>("");
  const [generatedCodeType, setGeneratedCodeType] = useState<string>("");
  const [isGeneratingCode, setIsGeneratingCode] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  
  // Mobile tab state
  const [mobileTab, setMobileTab] = useState<'chat' | 'code'>('chat');
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  
  // Streaming cancellation
  const abortControllerRef = useRef<AbortController | null>(null);

  // Python execution state
  const [pythonCode, setPythonCode] = useState<string>("");
  const [pythonOutput, setPythonOutput] = useState<string>("");
  const [isPythonExecuting, setIsPythonExecuting] = useState(false);
  const [pythonError, setPythonError] = useState<string>("");
  const [pythonExecutionTime, setPythonExecutionTime] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const tasks = [
    { id: 1, name: 'テキスト生成', icon: '✨', status: 'ready' },
    { id: 2, name: '画像生成', icon: '🖼', status: 'ready' },
    { id: 3, name: 'スライド作成', icon: '📊', status: 'ready' },
    { id: 4, name: 'Webアプリ作成', icon: '🚀', status: 'ready' },
    { id: 5, name: '音声生成', icon: '🎵', status: 'ready' },
    { id: 6, name: '動画生成', icon: '🎬', status: 'ready' },
    { id: 7, name: 'PDF生成', icon: '📄', status: 'ready' },
    { id: 8, name: 'ゲーム作成', icon: '🎮', status: 'ready' },
    { id: 9, name: 'Webサイト作成', icon: '🌐', status: 'ready' },
  ];

  // Queries
  const sessionsQuery = trpc.chat.getSessions.useQuery(undefined, {
    enabled: !!user,
  });
  const messagesQuery = trpc.chat.getMessages.useQuery(
    { sessionId: currentSessionId! },
    { enabled: !!currentSessionId }
  );

  // Mutations
  const createSessionMutation = trpc.chat.createSession.useMutation({
    onSuccess: (data) => {
      setCurrentSessionId(data.sessionId);
      setOptimisticMessages([]);
      setMessageInput("");
      sessionsQuery.refetch();
    },
  });

  const deleteSessionMutation = trpc.chat.deleteSession.useMutation({
    onSuccess: () => {
      setCurrentSessionId(null);
      sessionsQuery.refetch();
    },
  });

  const renameSessionMutation = trpc.chat.renameSession.useMutation({
    onSuccess: () => {
      setRenameDialogOpen(false);
      sessionsQuery.refetch();
    },
  });

  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const executePythonMutation = trpc.python.execute.useMutation();

  useEffect(() => {
    if (sessionsQuery.data && sessionsQuery.data.length > 0 && !currentSessionId) {
      setCurrentSessionId(sessionsQuery.data[0].id);
    }
  }, [sessionsQuery.data, currentSessionId]);

  useEffect(() => {
    const scrollElement = scrollRef.current;
    if (scrollElement) {
      scrollElement.scrollTop = scrollElement.scrollHeight;
    }
  }, [optimisticMessages]);

  const displayMessages = [
    ...(messagesQuery.data || []),
    ...optimisticMessages,
  ];

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles([...selectedFiles, ...files]);

    files.forEach((file) => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setImagePreviews((prev) => ({
            ...prev,
            [file.name]: event.target?.result as string,
          }));
        };
        reader.readAsDataURL(file);
      }
    });
  };

  const removeFile = (index: number) => {
    const file = selectedFiles[index];
    setSelectedFiles(selectedFiles.filter((_, i) => i !== index));
    if (file.type.startsWith('image/')) {
      setImagePreviews((prev) => {
        const newPreviews = { ...prev };
        delete newPreviews[file.name];
        return newPreviews;
      });
    }
  };

  const handleSendMessage = async () => {
    if (!messageInput.trim() && selectedFiles.length === 0) return;
    if (!currentSessionId) return;

    abortControllerRef.current = new AbortController();
    setIsStreaming(true);

    const userMessage = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: messageInput,
      imageUrl: undefined,
      isOptimistic: true,
      isStreaming: false,
    };

    setOptimisticMessages((prev) => [...prev, userMessage]);
    setMessageInput("");
    setSelectedFiles([]);
    setImagePreviews({});

    try {
      const response = await fetch("/api/chat/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: currentSessionId,
          message: messageInput,
          files: selectedFiles.map((f) => ({ name: f.name, size: f.size, type: f.type })),
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) throw new Error("Failed to send message");

      const reader = response.body?.getReader();
      if (!reader) throw new Error("No response body");

      let assistantMessage: any = {
        id: `msg-${Date.now()}-assistant`,
        role: "assistant",
        content: "",
        imageUrl: undefined,
        isOptimistic: true,
        isStreaming: true,
      };

      setOptimisticMessages((prev) => [...prev, assistantMessage]);

      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));

              if (data.type === "text") {
                assistantMessage.content += data.content;
                setOptimisticMessages((prev) => {
                  const updated = [...prev];
                  const lastMsg = updated[updated.length - 1];
                  if (lastMsg && lastMsg.id === assistantMessage.id) {
                    lastMsg.content = assistantMessage.content;
                  }
                  return updated;
                });
              } else if (data.type === "image") {
                assistantMessage.imageUrl = data.url;
                setOptimisticMessages((prev) => {
                  const updated = [...prev];
                  const lastMsg = updated[updated.length - 1];
                  if (lastMsg && lastMsg.id === assistantMessage.id) {
                    lastMsg.imageUrl = data.url;
                  }
                  return updated;
                });
              } else if (data.type === "python") {
                assistantMessage.pythonCode = data.code;
                setPythonCode(data.code);
                setMobileTab('code');
                setOptimisticMessages((prev) => {
                  const updated = [...prev];
                  const lastMsg = updated[updated.length - 1];
                  if (lastMsg && lastMsg.id === assistantMessage.id) {
                    lastMsg.pythonCode = data.code;
                  }
                  return updated;
                });
              } else if (data.type === "task") {
                if (data.action === "start") {
                  setActiveTasks((prev) => [...prev, data.task]);
                } else if (data.action === "update") {
                  setActiveTasks((prev) =>
                    prev.map((t) =>
                      t.type === data.task.type ? { ...t, ...data.task } : t
                    )
                  );
                } else if (data.action === "end") {
                  setActiveTasks((prev) =>
                    prev.filter((t) => t.type !== data.task.type)
                  );
                }
              }
            } catch (e) {
              console.error("Failed to parse SSE data:", e);
            }
          }
        }
      }

      assistantMessage.isStreaming = false;
      setOptimisticMessages((prev) => {
        const updated = [...prev];
        const lastMsg = updated[updated.length - 1];
        if (lastMsg && lastMsg.id === assistantMessage.id) {
          lastMsg.isStreaming = false;
        }
        return updated;
      });

      messagesQuery.refetch?.();
    } catch (error) {
      if (error instanceof Error && error.name !== "AbortError") {
        console.error("Error sending message:", error);
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  };

  const handleExecutePython = async () => {
    if (!pythonCode.trim()) return;

    setIsPythonExecuting(true);
    setPythonOutput("");
    setPythonError("");
    setPythonExecutionTime(null);

    try {
      const result = await executePythonMutation.mutateAsync({ code: pythonCode });

      if (result.success) {
        setPythonOutput(result.output || "(出力なし)");
        if (result.executionTime) {
          setPythonExecutionTime(result.executionTime);
        }
      } else {
        setPythonError(result.error || "エラーが発生しました");
      }
    } catch (error) {
      setPythonError(error instanceof Error ? error.message : "エラーが発生しました");
    } finally {
      setIsPythonExecuting(false);
    }
  };

  return (
    <div className="flex h-screen bg-white">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "w-64" : "w-0"
        } transition-all duration-300 bg-white border-r border-gray-200 flex flex-col overflow-hidden`}
      >
        {/* Header */}
        <div className="p-4 border-b border-gray-200 flex-shrink-0">
          <Button
            onClick={() => createSessionMutation.mutate({})}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            新しいチャット
          </Button>
        </div>

        {/* Sessions List */}
        <ScrollArea className="flex-1 overflow-y-auto">
          <div className="p-2 space-y-2">
            {sessionsQuery.data?.map((session) => (
              <div
                key={session.id}
                onClick={() => setCurrentSessionId(session.id)}
                className={`p-3 rounded-lg cursor-pointer transition-colors ${
                  currentSessionId === session.id
                    ? "bg-blue-100 text-blue-900"
                    : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{session.title}</p>
                  </div>
                  <div className="flex gap-1 flex-shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedSessionForRename(session.id);
                        setNewTitle(session.title);
                        setRenameDialogOpen(true);
                      }}
                      className="p-1 hover:bg-gray-200 rounded transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteSessionMutation.mutate({ sessionId: session.id });
                      }}
                      className="p-1 hover:bg-red-100 rounded transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        {/* Account Info Section - Fixed at Bottom with Dropdown */}
        <div className="border-t border-gray-200 bg-white p-4 flex-shrink-0">
          {user ? (
            <div className="relative">
              <button
                onClick={() => setAccountMenuOpen(!accountMenuOpen)}
                className="w-full flex items-center gap-3 hover:bg-gray-50 rounded-lg p-2 transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-semibold flex-shrink-0">
                  {user.name?.charAt(0).toUpperCase() || 'U'}
                </div>
                <div className="flex-1 min-w-0 text-left">
                  <div className="text-sm font-medium text-gray-900 truncate">{user.name}</div>
                  <div className="text-xs text-gray-500 truncate">{user.email}</div>
                </div>
                <ChevronDown className={`w-4 h-4 text-gray-600 flex-shrink-0 transition-transform ${
                  accountMenuOpen ? 'rotate-180' : ''
                }`} />
              </button>
              
              {accountMenuOpen && (
                <div className="absolute bottom-full left-0 right-0 mb-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                  <button
                    onClick={async () => {
                      await logout();
                      setAccountMenuOpen(false);
                    }}
                    className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition-colors flex items-center gap-2"
                  >
                    <LogOut className="w-4 h-4" />
                    ログアウト
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-sm text-gray-500">ログイン中...</div>
          )}
        </div>
      </div>

      {/* Main Content Area - Desktop */}
      <div className="hidden md:flex flex-1 flex-col bg-white">
        {/* Chat Panel */}
        <div className="flex flex-col bg-white h-full">
          {/* Header with Toggle Button */}
          <div className="border-b border-gray-200 bg-white px-3 md:px-6 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2 md:gap-4 min-w-0 flex-1">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                {sidebarOpen ? (
                  <X className="w-5 h-5 text-gray-700" />
                ) : (
                  <Menu className="w-5 h-5 text-gray-700" />
                )}
              </button>
              <h1 className="text-lg md:text-xl font-semibold text-gray-900 truncate">
                {sessionsQuery.data?.find(s => s.id === currentSessionId)?.title || "チャット"}
              </h1>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 px-3 md:px-6 py-4 overflow-x-hidden" ref={scrollRef}>
            <div className="max-w-4xl mx-auto space-y-4 w-full">
              {displayMessages.length === 0 ? (
                <div className="flex items-center justify-center h-96 text-gray-500">
                  <div className="text-center">
                    <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>メッセージを送信してAIと会話を始めましょう</p>
                  </div>
                </div>
              ) : (
                displayMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                        className={`max-w-xs md:max-w-2xl rounded-lg px-3 md:px-4 py-2 md:py-3 text-sm md:text-base ${
                        msg.role === "user"
                          ? "bg-blue-600 text-white"
                          : (msg as any).isOptimistic
                          ? "bg-gray-100 text-gray-700"
                          : "bg-gray-100 text-gray-900"
                      }`}
                    >
                      {msg.role === "assistant" ? (
                        <Streamdown>{msg.content}</Streamdown>
                      ) : (
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                      )}
                      {msg.imageUrl && (
                        <div className="mt-3 max-w-xs overflow-hidden">
                          <img
                            src={msg.imageUrl}
                            alt="Generated"
                            className="max-w-full h-auto rounded-lg"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>

          {/* Task Progress */}
          {activeTasks.length > 0 && (
            <div className="border-t border-gray-200 bg-gray-50 px-3 md:px-6 py-3">
              <button
                onClick={() => setTaskProgressOpen(!taskProgressOpen)}
                className="flex items-center gap-2 text-sm font-semibold text-gray-700 hover:text-gray-900 transition-colors"
              >
                <span>実行中のタスク ({activeTasks.length})</span>
                <span className={`transform transition-transform ${taskProgressOpen ? 'rotate-180' : ''}`}>▼</span>
              </button>
              
              {taskProgressOpen && (
                <div className="mt-3 space-y-2">
                  {activeTasks.map((task) => (
                    <div key={task.type} className="flex items-center gap-3 p-2 bg-white rounded-lg border border-gray-200">
                      <span className={task.status === 'running' ? 'animate-spin' : ''}>
                        {task.icon}
                      </span>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-700">{task.name}</div>
                        <div className="text-xs text-gray-500">
                          {task.status === 'running' ? '実行中...' : task.status === 'completed' ? '完了' : 'エラー'}
                        </div>
                      </div>
                      {task.status === 'running' && (
                        <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                      )}
                      {task.status === 'completed' && (
                        <span className="text-green-600">✓</span>
                      )}
                      {task.status === 'error' && (
                        <span className="text-red-600">✕</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Input Area */}
          <div className="border-t border-gray-200 bg-white px-3 md:px-4 py-4 flex-shrink-0">
            <div className="max-w-4xl mx-auto space-y-3 w-full">
              {/* File Preview Section */}
              {selectedFiles.length > 0 && (
                <div className="pb-3 border-b border-gray-200">
                  {/* Image Previews */}
                  {Object.keys(imagePreviews).length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-3">
                      {selectedFiles.map((file, index) => 
                        imagePreviews[file.name] ? (
                          <div key={index} className="relative">
                            <img
                              src={imagePreviews[file.name]}
                              alt={file.name}
                              className="h-20 w-20 object-cover rounded-lg border border-gray-300"
                            />
                            <button
                              onClick={() => removeFile(index)}
                              className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-1 hover:bg-red-700 transition-colors shadow-md"
                            >
                              <XIcon className="w-4 h-4" />
                            </button>
                          </div>
                        ) : null
                      )}
                    </div>
                  )}
                  
                  {/* File List (non-image files) */}
                  {selectedFiles.some(f => !f.type.startsWith('image/')) && (
                    <div className="flex flex-wrap gap-2">
                      {selectedFiles.map((file, index) => 
                        !file.type.startsWith('image/') ? (
                          <div key={index} className="flex items-center gap-2 bg-gray-100 rounded-lg px-3 py-2">
                            <Paperclip className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-700 max-w-xs truncate">{file.name}</span>
                            <button
                              onClick={() => removeFile(index)}
                              className="text-gray-500 hover:text-red-600 transition-colors"
                            >
                              <XIcon className="w-4 h-4" />
                            </button>
                          </div>
                        ) : null
                      )}
                    </div>
                  )}
                </div>
              )}
              
              {/* Input Row */}
              <div className="flex gap-2 w-full">
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={handleFileSelect}
                  className="hidden"
                  accept="*/*"
                />
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                  className="flex-shrink-0 px-3 md:px-4 border-gray-300"
                  disabled={isStreaming}
                >
                  <Paperclip className="w-4 h-4" />
                </Button>
                <Input
                  placeholder="メッセージを入力..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  disabled={isStreaming}
                  className="flex-1 bg-white border-gray-300 text-gray-900 placeholder-gray-500 text-sm md:text-base"
                />
                <Button
                  onClick={() => {
                    if (isStreaming) {
                      abortControllerRef.current?.abort();
                      setIsStreaming(false);
                      setActiveTasks([]);
                    } else {
                      handleSendMessage();
                    }
                  }}
                  disabled={!isStreaming && (!messageInput.trim() && selectedFiles.length === 0)}
                  className={`flex-shrink-0 px-3 md:px-4 text-white ${
                    isStreaming
                      ? 'bg-red-600 hover:bg-red-700'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {isStreaming ? (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <rect x="6" y="4" width="4" height="16" />
                      <rect x="14" y="4" width="4" height="16" />
                    </svg>
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile View with Tabs */}
      <div className="md:hidden flex-1 flex flex-col bg-white">
        {/* Tab Navigation */}
        <div className="border-b border-gray-200 bg-white flex">
          <button
            onClick={() => setMobileTab('chat')}
            className={`flex-1 px-4 py-3 text-center font-medium transition-colors ${
              mobileTab === 'chat'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-600 border-b-2 border-transparent hover:text-gray-900'
            }`}
          >
            チャット
          </button>
          <button
            onClick={() => setMobileTab('code')}
            className={`flex-1 px-4 py-3 text-center font-medium transition-colors ${
              mobileTab === 'code'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-600 border-b-2 border-transparent hover:text-gray-900'
            }`}
          >
            コード
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 relative overflow-hidden">
          {/* Chat Tab */}
          <div
            className={`absolute inset-0 h-full flex flex-col transition-all duration-300 ease-in-out ${
              mobileTab === 'chat'
                ? 'translate-x-0 opacity-100'
                : '-translate-x-full opacity-0'
            }`}
          >
            {/* Header */}
            <div className="border-b border-gray-200 bg-white px-3 py-3 flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <button
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  {sidebarOpen ? (
                    <X className="w-5 h-5 text-gray-700" />
                  ) : (
                    <Menu className="w-5 h-5 text-gray-700" />
                  )}
                </button>
                <h1 className="text-lg font-semibold text-gray-900 truncate">
                  {sessionsQuery.data?.find(s => s.id === currentSessionId)?.title || "チャット"}
                </h1>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 px-3 py-4 overflow-x-hidden">
              <div className="space-y-4 w-full">
                {displayMessages.length === 0 ? (
                  <div className="flex items-center justify-center h-96 text-gray-500">
                    <div className="text-center">
                      <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>メッセージを送信してAIと会話を始めましょう</p>
                    </div>
                  </div>
                ) : (
                  displayMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-xs rounded-lg px-3 py-2 text-sm ${
                          msg.role === "user"
                            ? "bg-blue-600 text-white"
                            : (msg as any).isOptimistic
                            ? "bg-gray-100 text-gray-700"
                            : "bg-gray-100 text-gray-900"
                        }`}
                      >
                        {msg.role === "assistant" ? (
                          <Streamdown>{msg.content}</Streamdown>
                        ) : (
                          <p className="whitespace-pre-wrap">{msg.content}</p>
                        )}
                        {msg.imageUrl && (
                          <div className="mt-3 max-w-xs overflow-hidden">
                            <img
                              src={msg.imageUrl}
                              alt="Generated"
                              className="max-w-full h-auto rounded-lg"
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>

            {/* Task Progress */}
            {activeTasks.length > 0 && (
              <div className="border-t border-gray-200 bg-gray-50 px-3 py-3 flex-shrink-0">
                <button
                  onClick={() => setTaskProgressOpen(!taskProgressOpen)}
                  className="flex items-center gap-2 text-sm font-semibold text-gray-700 hover:text-gray-900 transition-colors"
                >
                  <span>実行中のタスク ({activeTasks.length})</span>
                  <span className={`transform transition-transform ${taskProgressOpen ? 'rotate-180' : ''}`}>▼</span>
                </button>
                
                {taskProgressOpen && (
                  <div className="mt-3 space-y-2">
                    {activeTasks.map((task) => (
                      <div key={task.type} className="flex items-center gap-3 p-2 bg-white rounded-lg border border-gray-200">
                        <span className={task.status === 'running' ? 'animate-spin' : ''}>
                          {task.icon}
                        </span>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-700">{task.name}</div>
                          <div className="text-xs text-gray-500">
                            {task.status === 'running' ? '実行中...' : task.status === 'completed' ? '完了' : 'エラー'}
                          </div>
                        </div>
                        {task.status === 'running' && (
                          <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                        )}
                        {task.status === 'completed' && (
                          <span className="text-green-600">✓</span>
                        )}
                        {task.status === 'error' && (
                          <span className="text-red-600">✕</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Input Area */}
            <div className="border-t border-gray-200 bg-white px-3 py-4 flex-shrink-0">
              <div className="space-y-3 w-full">
                {/* File Preview Section */}
                {selectedFiles.length > 0 && (
                  <div className="pb-3 border-b border-gray-200">
                    {/* Image Previews */}
                    {Object.keys(imagePreviews).length > 0 && (
                      <div className="flex flex-wrap gap-2 mb-3">
                        {selectedFiles.map((file, index) => 
                          imagePreviews[file.name] ? (
                            <div key={index} className="relative">
                              <img
                                src={imagePreviews[file.name]}
                                alt={file.name}
                                className="h-20 w-20 object-cover rounded-lg border border-gray-300"
                              />
                              <button
                                onClick={() => removeFile(index)}
                                className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-1 hover:bg-red-700 transition-colors shadow-md"
                              >
                                <XIcon className="w-4 h-4" />
                              </button>
                            </div>
                          ) : null
                        )}
                      </div>
                    )}
                    
                    {/* File List (non-image files) */}
                    {selectedFiles.some(f => !f.type.startsWith('image/')) && (
                      <div className="flex flex-wrap gap-2">
                        {selectedFiles.map((file, index) => 
                          !file.type.startsWith('image/') ? (
                            <div key={index} className="flex items-center gap-2 bg-gray-100 rounded-lg px-3 py-2">
                              <Paperclip className="w-4 h-4 text-gray-600" />
                              <span className="text-sm text-gray-700 max-w-xs truncate">{file.name}</span>
                              <button
                                onClick={() => removeFile(index)}
                                className="text-gray-500 hover:text-red-600 transition-colors"
                              >
                                <XIcon className="w-4 h-4" />
                              </button>
                            </div>
                          ) : null
                        )}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Input Row */}
                <div className="flex gap-2 w-full">
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    onChange={handleFileSelect}
                    className="hidden"
                    accept="*/*"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    className="flex-shrink-0 px-3 border-gray-300"
                    disabled={isStreaming}
                  >
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Input
                    placeholder="メッセージを入力..."
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    disabled={isStreaming}
                    className="flex-1 bg-white border-gray-300 text-gray-900 placeholder-gray-500 text-sm"
                  />
                  <Button
                    onClick={() => {
                      if (isStreaming) {
                        abortControllerRef.current?.abort();
                        setIsStreaming(false);
                        setActiveTasks([]);
                      } else {
                        handleSendMessage();
                      }
                    }}
                    disabled={!isStreaming && (!messageInput.trim() && selectedFiles.length === 0)}
                    className={`flex-shrink-0 px-3 text-white ${
                      isStreaming
                        ? 'bg-red-600 hover:bg-red-700'
                        : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {isStreaming ? (
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                        <rect x="6" y="4" width="4" height="16" />
                        <rect x="14" y="4" width="4" height="16" />
                      </svg>
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Code Tab - Python Executor */}
          <div
            className={`absolute inset-0 h-full flex flex-col transition-all duration-300 ease-in-out ${
              mobileTab === 'code'
                ? 'translate-x-0 opacity-100'
                : 'translate-x-full opacity-0'
            }`}
          >
            {/* Header */}
            <div className="border-b border-gray-200 bg-white px-4 py-3 flex items-center justify-between flex-shrink-0">
              <h2 className="font-semibold text-gray-900">Pythonコード実行</h2>
            </div>

            {/* Content */}
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Code Editor */}
              <div className="flex-1 border-b border-gray-200 overflow-hidden flex flex-col">
                <div className="px-4 py-2 bg-gray-50 border-b border-gray-200">
                  <p className="text-xs text-gray-600">Pythonコードを入力してください</p>
                </div>
                <textarea
                  value={pythonCode}
                  onChange={(e) => setPythonCode(e.target.value)}
                  placeholder="print('Hello, World!')\n\n# ここにPythonコードを入力"
                  className="flex-1 p-4 font-mono text-sm bg-gray-900 text-gray-100 resize-none focus:outline-none"
                  disabled={isPythonExecuting}
                />
              </div>

              {/* Output/Error Display */}
              <div className="flex-1 border-b border-gray-200 overflow-auto bg-gray-50">
                {isPythonExecuting ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center">
                      <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-blue-600" />
                      <p className="text-gray-600 text-sm">実行中...</p>
                    </div>
                  </div>
                ) : pythonError ? (
                  <div className="p-4">
                    <div className="text-sm font-semibold text-red-600 mb-2">エラー</div>
                    <pre className="bg-red-50 p-3 rounded text-xs text-red-800 overflow-auto whitespace-pre-wrap break-words">
                      {pythonError}
                    </pre>
                  </div>
                ) : pythonOutput ? (
                  <div className="p-4">
                    <div className="text-sm font-semibold text-gray-700 mb-2">出力</div>
                    <pre className="bg-white p-3 rounded text-xs text-gray-800 overflow-auto whitespace-pre-wrap break-words border border-gray-200">
                      {pythonOutput}
                    </pre>
                    {pythonExecutionTime && (
                      <div className="mt-2 text-xs text-gray-500">
                        実行時間: {pythonExecutionTime}ms
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-500">
                    <div className="text-center">
                      <p className="text-sm">コードを実行すると結果がここに表示されます</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Execute Button */}
              <div className="border-t border-gray-200 bg-white px-4 py-3 flex-shrink-0">
                <Button
                  onClick={handleExecutePython}
                  disabled={isPythonExecuting || !pythonCode.trim()}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {isPythonExecuting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      実行中...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      実行
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Rename Dialog */}
      <Dialog open={renameDialogOpen} onOpenChange={setRenameDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>チャット名を変更</DialogTitle>
          </DialogHeader>
          <Input
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="新しいチャット名"
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                if (selectedSessionForRename) {
                  renameSessionMutation.mutate({
                    sessionId: selectedSessionForRename,
                    title: newTitle,
                  });
                }
              }
            }}
          />
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setRenameDialogOpen(false)}>
              キャンセル
            </Button>
            <Button
              onClick={() => {
                if (selectedSessionForRename) {
                  renameSessionMutation.mutate({
                    sessionId: selectedSessionForRename,
                    title: newTitle,
                  });
                }
              }}
            >
              変更
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
